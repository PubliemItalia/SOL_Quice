-- phpMyAdmin SQL Dump
-- version 3.4.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 29, 2016 at 08:25 AM
-- Server version: 5.5.39
-- PHP Version: 5.4.32

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `quice_php`
--

-- --------------------------------------------------------

--
-- Table structure for table `parametri_backup`
--

CREATE TABLE IF NOT EXISTS `parametri_backup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `mail_partenza` text NOT NULL,
  `mail_destinazione1` text NOT NULL,
  `mail_destinazione2` text NOT NULL,
  `mail_amministratore` tinytext NOT NULL,
  `flag_mail1` tinyint(1) NOT NULL,
  `flag_mail2` tinyint(1) NOT NULL,
  `flag_mail_approvazione` tinyint(1) NOT NULL,
  `smtp_server` text NOT NULL,
  `ultimo_backup` int(11) NOT NULL,
  `intervallo_backup_automatico` int(11) NOT NULL,
  `operatore_ultimo_backup` text NOT NULL,
  `db_server` text NOT NULL,
  `db` text NOT NULL,
  `mysql_username` text NOT NULL,
  `mysql_password` text NOT NULL,
  `max_num_file` tinyint(4) NOT NULL,
  `ultima_modifica` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `parametri_backup`
--

INSERT INTO `parametri_backup` (`id`, `mail_partenza`, `mail_destinazione1`, `mail_destinazione2`, `mail_amministratore`, `flag_mail1`, `flag_mail2`, `flag_mail_approvazione`, `smtp_server`, `ultimo_backup`, `intervallo_backup_automatico`, `operatore_ultimo_backup`, `db_server`, `db`, `mysql_username`, `mysql_password`, `max_num_file`, `ultima_modifica`) VALUES
(1, 'server@sol.it', 'luigi.riva@dtpc.it', '', '', 1, 0, 0, '10.0.1.148', 1380109632, 120, 'sistema', 'localhost', 'interm', 'root', 'enapsoam', 10, '2013-10-03 14:19:32');

-- --------------------------------------------------------

--
-- Table structure for table `phpmysqlautobackup`
--

CREATE TABLE IF NOT EXISTS `phpmysqlautobackup` (
  `id` int(11) NOT NULL,
  `version` varchar(6) DEFAULT NULL,
  `time_last_run` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `phpmysqlautobackup`
--

INSERT INTO `phpmysqlautobackup` (`id`, `version`, `time_last_run`) VALUES
(1, '1.5.4', 1380809625);

-- --------------------------------------------------------

--
-- Table structure for table `qui_buyer_funzioni`
--

CREATE TABLE IF NOT EXISTS `qui_buyer_funzioni` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `user_name` text NOT NULL,
  `F_gestione` tinyint(1) NOT NULL,
  `F_report` tinyint(1) NOT NULL,
  `F_fatturazione` tinyint(1) NOT NULL,
  `F_fatt_visual` tinyint(1) NOT NULL,
  `F_magazzino` tinyint(1) NOT NULL,
  `F_approvazione` tinyint(1) NOT NULL,
  `F_amm_prodotti` tinyint(1) NOT NULL,
  `F_amm_ordini` tinyint(1) NOT NULL,
  `F_gestione_sap` tinyint(1) NOT NULL,
  `F_amm_giacenze` tinyint(4) NOT NULL,
  `negozio` varchar(40) NOT NULL,
  `mail` text NOT NULL,
  `riceve_email_rda` tinyint(1) NOT NULL,
  `azienda` varchar(30) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=26 ;

--
-- Dumping data for table `qui_buyer_funzioni`
--

INSERT INTO `qui_buyer_funzioni` (`id`, `user_id`, `user_name`, `F_gestione`, `F_report`, `F_fatturazione`, `F_fatt_visual`, `F_magazzino`, `F_approvazione`, `F_amm_prodotti`, `F_amm_ordini`, `F_gestione_sap`, `F_amm_giacenze`, `negozio`, `mail`, `riceve_email_rda`, `azienda`) VALUES
(1, 9, 'Alberto Cimignaghi', 1, 1, 1, 1, 0, 0, 1, 1, 0, 1, 'assets', 'a.cimignaghi@sol.it', 1, ''),
(2, 32, 'Alfredo Balconi', 1, 1, 1, 1, 0, 0, 1, 1, 0, 1, 'consumabili', '', 0, ''),
(3, 201, 'Fabio Muzzi', 1, 1, 1, 1, 0, 0, 1, 1, 0, 1, 'assets', 'f.muzzi@sol.it', 1, ''),
(4, 251, 'Giacomo Cavalli', 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 'spare_parts', 'g.cavalli@sol.it', 1, ''),
(5, 272, 'Giorgio Gaiani', 0, 1, 0, 0, 1, 0, 0, 0, 0, 1, 'consumabili', '', 0, ''),
(6, 400, 'Marco Ruggiero', 1, 1, 1, 1, 0, 0, 1, 0, 0, 1, '', 'm.ruggiero@vivisol.it', 0, ''),
(7, 473, 'Nicoletta Canegrati', 1, 1, 1, 1, 0, 0, 1, 1, 0, 1, 'consumabili', '', 0, ''),
(8, 1646, 'Stefano Giagnorio', 1, 1, 1, 1, 0, 0, 1, 1, 0, 1, 'assets', 's.giagnorio@sol.it', 1, ''),
(9, 10004, 'AAA-MAGAZZINIERE', 0, 1, 0, 0, 1, 0, 1, 0, 0, 1, '', '', 0, ''),
(10, 10003, 'AAA-BUYER1', 1, 1, 1, 1, 0, 1, 1, 1, 0, 1, 'consumabili', 'luigi.riva@publiem.it', 0, ''),
(11, 161, 'Diego Cassini', 1, 1, 1, 1, 0, 0, 1, 1, 0, 1, 'consumabili', '', 0, ''),
(12, 389, 'Marco Guerrini', 0, 1, 1, 1, 0, 0, 1, 0, 0, 1, 'spare_parts', 'm.guerrini@sol.it', 1, ''),
(13, 563, 'Sabrina Fraccaroli', 0, 1, 1, 0, 0, 0, 0, 0, 0, 1, '', '', 0, ''),
(14, 303, 'Grazia Scotti', 0, 1, 1, 1, 0, 0, 0, 1, 1, 1, '', 'g.scotti@sol.it', 1, 'sol'),
(18, 532, 'Riccardo Bandoni', 0, 1, 1, 1, 0, 0, 0, 1, 1, 1, 'consumabili', 'r.bandoni@sol.it', 0, ''),
(16, 10005, 'Buyer Pharma', 1, 1, 1, 1, 0, 0, 0, 1, 1, 1, 'labels', 'diego.sala@publiem.it', 0, ''),
(17, 1449, 'Carla perego', 0, 1, 1, 1, 0, 0, 0, 1, 1, 1, 'consumabili', 'c.perego@sol.it', 0, ''),
(19, 72, 'Anna Maria Pistillo', 0, 1, 1, 1, 0, 0, 0, 1, 1, 1, '', 'a.pistillo@sol.it', 1, 'vivisol'),
(20, 1028, 'Francesco Masangui', 0, 1, 0, 0, 1, 0, 0, 0, 0, 1, 'vivistore', '', 0, ''),
(21, 2298, 'Luciano Redaelli', 0, 1, 0, 0, 1, 0, 0, 0, 0, 1, 'vivistore', '', 0, ''),
(22, 544, 'Roberto Forlani', 1, 1, 1, 1, 0, 0, 1, 0, 0, 1, '', 'r.forlani@vivisol.it', 0, ''),
(23, 2453, 'Lorenzo Belli', 1, 1, 1, 1, 0, 0, 1, 0, 0, 1, '', 'l.belli@vivisol.it', 0, ''),
(24, 2455, 'Matteo Fregata', 0, 1, 0, 0, 1, 0, 0, 0, 0, 1, 'vivistore', '', 0, ''),
(25, 2466, 'Prathapa Kumudu Bandara Widana Rallage', 0, 1, 0, 0, 1, 0, 0, 0, 0, 1, 'vivistore', '', 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `qui_buyer_negozi`
--

CREATE TABLE IF NOT EXISTS `qui_buyer_negozi` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nome_utente` varchar(60) NOT NULL,
  `id_utente` int(11) NOT NULL,
  `id_magazziniere` int(11) NOT NULL,
  `nome_magazziniere` varchar(70) NOT NULL,
  `negozio` varchar(40) NOT NULL,
  `flusso` varchar(50) NOT NULL,
  `preferenza` int(11) NOT NULL,
  `mail` varchar(80) NOT NULL,
  `riceve_mail_xnegozio` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=40 ;

--
-- Dumping data for table `qui_buyer_negozi`
--

INSERT INTO `qui_buyer_negozi` (`id`, `nome_utente`, `id_utente`, `id_magazziniere`, `nome_magazziniere`, `negozio`, `flusso`, `preferenza`, `mail`, `riceve_mail_xnegozio`) VALUES
(1, 'cassini', 161, 0, '', 'consumabili', '', 1, 'd.cassini@sol.it', 0),
(2, 'cassini', 161, 0, '', 'spare_parts', '', 2, 'd.cassini@sol.it', 0),
(3, 'cassini', 161, 0, '', 'labels', '', 3, 'd.cassini@sol.it', 0),
(4, 'balconi', 32, 0, '', 'consumabili', '', 1, 'a.balconi@sol.it', 0),
(5, 'balconi', 32, 0, '', 'spare_parts', '', 2, 'a.balconi@sol.it', 0),
(6, 'balconi', 32, 0, '', 'labels', '', 3, 'a.balconi@sol.it', 0),
(7, 'muzzi', 201, 0, '', 'assets', '', 1, 'f.muzzi@sol.it', 0),
(8, 'giagnorio', 1646, 0, '', 'assets', '', 1, 's.giagnorio@sol.it', 0),
(9, 'canegrati', 473, 0, '', 'consumabili', '', 1, 'n.canegrati@sol.it', 0),
(10, 'canegrati', 473, 0, '', 'spare_parts', '', 2, 'n.canegrati@sol.it', 0),
(11, 'canegrati', 473, 0, '', 'labels', '', 3, 'n.canegrati@sol.it', 0),
(12, 'cimignaghi', 9, 0, '', 'assets', '', 1, 'a.cimignaghi@sol.it', 0),
(19, 'AAA-BUYER1', 10003, 0, '', 'consumabili', '', 1, 'mara.girardi@publiem.it', 0),
(14, 'cavalli', 251, 0, '', 'spare_parts', '', 1, 'g.cavalli@sol.it', 0),
(15, 'guerrini', 389, 0, '', 'spare_parts', '', 1, 'm.guerrini@sol.it', 0),
(16, 'gaiani', 272, 0, '', 'consumabili', 'mag', 1, 'g.gaiani@sol.it', 0),
(17, 'gaiani', 272, 0, '', 'spare_parts', 'mag', 2, 'g.gaiani@sol.it', 0),
(18, 'gaiani', 272, 0, '', 'labels', 'mag', 3, 'g.gaiani@sol.it', 0),
(20, 'AAA-BUYER1', 10003, 0, '', 'spare_parts', '', 2, 'mara.girardi@publiem.it', 0),
(21, 'AAA-BUYER1', 10003, 0, '', 'labels', '', 3, 'mara.girardi@publiem.it', 0),
(22, 'AAA-BUYER1', 10003, 0, '', 'assets', '', 4, 'mara.girardi@publiem.it', 0),
(23, 'balconi', 32, 0, '', 'vivistore', '', 3, 'a.balconi@sol.it', 0),
(24, 'AAA-BUYER1', 10003, 0, '', 'vivistore', '', 2, 'mara.girardi@publiem.it', 0),
(25, 'grazia scotti', 303, 0, '', 'consumabili', '', 1, 'g.scotti@sol.it', 0),
(26, 'grazia scotti', 303, 0, '', 'spare_parts', '', 2, 'g.scotti@sol.it', 0),
(27, 'grazia scotti', 303, 0, '', 'labels', '', 3, 'g.scotti@sol.it', 0),
(28, 'grazia scotti', 303, 0, '', 'vivistore', '', 4, 'g.scotti@sol.it', 0),
(29, 'grazia scotti', 303, 0, '', 'assets', '', 5, 'g.scotti@sol.it', 0),
(39, 'Lorenzo Belli', 2453, 0, '', 'vivistore', 'htc', 1, 'l.belli@vivisol.it', 0),
(38, 'Prathapa Kumudu Bandara Widana Rallage', 2466, 0, '', 'vivistore', 'htc', 1, 'k.rallage@vivisol.it', 0),
(37, 'Matteo Fregata', 2455, 0, '', 'vivistore', 'htc', 1, 'm.fregata@vivisol.it', 0),
(36, 'forlani', 544, 0, '', 'vivistore', 'htc', 1, 'r.forlani@vivisol.it', 0),
(34, 'AAA-MAGAZZINIERE', 10004, 0, '', 'labels', 'lab', 1, 'luigi.riva@dtpc.it', 0),
(33, 'Luciano Redaelli', 2298, 0, '', 'vivistore', 'bmc', 1, 'luciano.redaelli@sol.it	', 0),
(32, 'Francesco Masangui', 1028, 0, '', 'vivistore', 'bmc', 1, 'f.masangui@sol.it', 0),
(31, 'ruggiero', 400, 0, '', 'vivistore', 'bmc', 1, 'm.ruggiero@vivisol.it', 0),
(30, 'AAA-BUYER-PHARMA', 10005, 10004, 'AAA-MAGAZZINIERE', 'labels', '', 1, 'mara.girardi@publiem.it', 0);

-- --------------------------------------------------------

--
-- Table structure for table `qui_catalogo`
--

CREATE TABLE IF NOT EXISTS `qui_catalogo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `part_number` varchar(100) NOT NULL,
  `obsoleto` tinyint(1) NOT NULL,
  `id_negozio` int(11) NOT NULL,
  `negozio` tinytext NOT NULL,
  `azienda` varchar(40) NOT NULL,
  `ric_mag` varchar(4) NOT NULL,
  `paese` tinytext NOT NULL,
  `foto_paese` varchar(30) NOT NULL,
  `flusso` varchar(50) NOT NULL,
  `categoria1_it` tinytext NOT NULL,
  `categoria2_it` tinytext NOT NULL,
  `categoria3_it` tinytext NOT NULL,
  `categoria4_it` tinytext NOT NULL,
  `extra` tinytext NOT NULL,
  `variante_pharma` varchar(25) NOT NULL,
  `etich_x_foglio` int(11) NOT NULL,
  `art_x_conf_ric` int(11) NOT NULL,
  `descrizione1_it` text NOT NULL,
  `descrizione2_it` text NOT NULL,
  `descrizione3_it` text NOT NULL,
  `descrizione4_it` text NOT NULL,
  `id_valvola` tinytext NOT NULL,
  `id_cappellotto` tinytext NOT NULL,
  `id_pescante` tinytext NOT NULL,
  `codice_art` tinytext NOT NULL,
  `cf` tinytext NOT NULL,
  `prodotto_multilingue` text NOT NULL,
  `codice_numerico` tinytext NOT NULL,
  `gruppo_merci` tinytext NOT NULL,
  `coge` tinytext NOT NULL,
  `wbs` tinytext NOT NULL,
  `prezzo` float(14,2) NOT NULL,
  `prezzo2` float(14,2) NOT NULL,
  `confezione` tinytext NOT NULL,
  `um` varchar(60) NOT NULL,
  `foto` text NOT NULL,
  `foto_sost` text NOT NULL,
  `foto_famiglia` text NOT NULL,
  `icona` text NOT NULL,
  `rif_famiglia` text NOT NULL,
  `precedenza` int(11) NOT NULL,
  `precedenza_int` int(11) NOT NULL,
  `categoria1_en` tinytext NOT NULL,
  `categoria2_en` tinytext NOT NULL,
  `categoria3_en` tinytext NOT NULL,
  `categoria4_en` tinytext NOT NULL,
  `descrizione1_en` text NOT NULL,
  `descrizione2_en` text NOT NULL,
  `descrizione3_en` text NOT NULL,
  `descrizione4_en` text NOT NULL,
  `filepath` text NOT NULL,
  `codice_originale_duplicato` tinytext NOT NULL,
  `ordine_stampa` tinyint(1) NOT NULL,
  `switch_lista_radio` tinyint(1) NOT NULL,
  `ultima_modifica` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `percorso_pdf` text NOT NULL,
  `simbolo_blister` varchar(10) NOT NULL,
  `soglia` int(11) NOT NULL,
  `gestione_scorta` tinyint(1) NOT NULL,
  `giacenza` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `qui_company`
--

CREATE TABLE IF NOT EXISTS `qui_company` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `IDCompany` int(11) NOT NULL,
  `Company` varchar(100) NOT NULL,
  `denominazione` varchar(250) NOT NULL,
  `denominazione2` varchar(250) NOT NULL,
  `indirizzo` text NOT NULL,
  `localita` varchar(250) NOT NULL,
  `cap` varchar(8) NOT NULL,
  `nazione` varchar(50) NOT NULL,
  `tel` varchar(100) NOT NULL,
  `fax` varchar(100) NOT NULL,
  `mail` varchar(100) NOT NULL,
  `sito` varchar(100) NOT NULL,
  `Ordine` int(11) NOT NULL,
  `CodSAP` varchar(20) NOT NULL,
  `IDNazione` int(11) NOT NULL,
  `Prefisso` varchar(40) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=78 ;

--
-- Dumping data for table `qui_company`
--

INSERT INTO `qui_company` (`id`, `IDCompany`, `Company`, `denominazione`, `denominazione2`, `indirizzo`, `localita`, `cap`, `nazione`, `tel`, `fax`, `mail`, `sito`, `Ordine`, `CodSAP`, `IDNazione`, `Prefisso`) VALUES
(2, 55, 'Airsol', '', '', '', '', '', '', '', '', '', '', 0, '', 5, 'airsol'),
(3, 3, 'Behringer srl', 'BEHRINGER Srl', '', 'Via Gualco, 4', 'Genova', '16165', 'Italy', 't +39 (0)10 8309103', 'f +39 (0)10 8309183', 'e info@behringer.it', 'www.behringer.it', 0, 'C4500', 1, 'behringer'),
(4, 43, 'BiotechSol', 'BIOTECHSOL Srl', '', 'Via Borgazzi, 27', 'Monza', '20900', 'Italy', 't +39 (0)39 2396 274', 'F +39 (0)39 2396 472', 'e biotechsol@pec.sol.it', 'www.biotechsol.com', 0, '', 1, 'biotechsol'),
(5, 4, 'BTG', 'BTG Belgische Technische Gassen', '', 'Zoning Ouest, 15', 'Lessines', 'B-7860', 'Belgium', 't +32 (0)68 700333', 'f +32 (0)68 338685', '', '', 0, 'C2100', 3, 'btg'),
(6, 52, 'BTG Gases', 'BTG Gases', '', 'Data House Station Road<br>Harrietsham Maidstone', 'Kent ME171JA', '', 'United Kingdom', 't +44 (0)1622 851415', 'f +44 (0)1622 854860', 'info@btggases.com', 'www.btggases.com', 0, 'C2105', 20, 'btg'),
(7, 57, 'Cryolab', 'CRYOLAB', 'Università degli Studi di Roma<br>Tor Vergata Edificio H', 'Via Montpellier, 1', 'Roma', '00133', 'Italy', 't +39 (0)6 993 67 313', '', 'e info@cryolab.it', '', 0, '', 1, 'cryolab'),
(8, 48, 'CTS', 'Centro Automezzi ', '', 'Via Firmio Leonzio 2', 'Salerno', '84100', 'Italy', '', '', '', '', 0, '', 1, 'cts'),
(9, 48, 'CTS', 'Centro Automezzi ', '', 'Viale del Lavoro 12', 'San Martino Buon Albergo (VR) ', '37036', 'Italy', '', '', '', '', 0, '', 1, 'cts'),
(10, 48, 'CTS', 'Centro Automezzi ', '', 'Via Baiona 154 ', 'Ravenna', '48100', 'Italy', '', '', '', '', 0, '', 1, 'cts'),
(11, 47, 'Diatheva', 'DIATHEVA Srl', '', 'Via Roma, 117/F', 'Fano (PU)', '61032', 'Italy', 't +39 (0)721 830605', 'f +39 (0)721 837154', 'e info@diatheva.com', 'www.diatheva.com', 0, 'C4700', 1, 'diatheva'),
(12, 41, 'Dolby Medical', '', '', '', '', '', '', '', '', '', '', 0, 'C4400', 20, 'dolby'),
(13, 37, 'ENERGETIKA', 'ENERGETIKA ZJ, d.o.o.', '', 'Cesta železarjev 8', 'Jesenice', '4270', 'Slovenia', 't +386 (0)4 5833324', 'f +386 (0)4 5833328', 'e info@e-zj.si', '', 0, '', 2, 'energetika'),
(14, 56, 'Flosit', 'Flosit S.A.', '', 'Aéropole Nouasseur', 'Casablanca', '20240', 'Morocco', 'T +212 (0)5225 39367', 'f +212 (0)5225 39296', '', '', 0, '', 23, 'flosit'),
(15, 5, 'France Oxygène', '', '', '', '', '', '', '', '', '', '', 0, '', 4, 'frox'),
(16, 38, 'GTH', 'GTH s.a.', '', 'Bulevardul Theodor Pallady 319', 'Bucharest', '', 'Romania', 't +40 (0)21 3450802', 'f +40 (0)21 3450801', 'e office@gth.ro', 'www.gazoteh.ro', 0, '', 18, 'gth'),
(17, 6, 'GTS', 'GTS Gazra Teknike Shqiptare Sh.P.K', '', 'Kombinat, Vaqarr', 'Tirane', '', 'Albania', 't +355 (0)43 50981', 'f +355 (0)43 52877', 'e info@gts.al', 'www.gts.al', 0, 'C3300', 15, 'gts'),
(18, 7, 'ICOA', 'ICOA Srl', '', 'Zona Industriale', 'Porto Salvo di Vibo Valentia', '89900', 'Italy', 't +39 (0)963 567241', 'f +39 (0)963 567243', 'e icoasrl@sol.it', 'www.icoasrl.it', 0, '', 1, 'icoa'),
(19, 8, 'Il Point', '', '', '', '', '', '', '', '', '', '', 0, 'C5950', 1, 'ilpoint'),
(20, 10, 'KISIKANA', 'Kisikana d.o.o.', 'Član SOL-INA Grupe', 'Stjepana i Antuna Radića, 17', 'Sisak', '44000', 'Croatia', 't +385 (0)44 534852', 'f +385 (0)44 534851', '', 'www.kisikana.hr', 0, '', 11, 'kisikana'),
(21, 45, 'MEDES', 'MEDES Srl', '', 'Via Fratelli Rosselli, 8/A', 'Settimo Milanese (MI)', '20019', 'Italy', 't +39 (0)2 3287 694', 'f +39 (0)2 3350 0971', '', '', 0, '', 1, 'medes'),
(22, 39, 'SICGIL SOL', 'SICGILSOL Gases', 'S.F.NO.29, Trichy-Tanjore', 'Main Road Pudukkudi', 'Tanjore', '613 402', 'India', 't +91 (0)44 42141467', '', '', '', 0, '', 19, 'sicgilsol'),
(23, 39, 'SICGIL SOL', 'SICGILSOL India', '', 'Dhun Building - 84 Anna Salai', 'Chennai', '600-002', 'India', 't +91 (0)44 28521644', '', '', 'www.sicgilsol.com', 0, '', 19, 'sicgilsol'),
(24, 17, 'SOL Bulgaria', 'SOL Bulgaria EAD', '', '12 Vladayska reka str.', 'Sofia', '1510', 'Bulgaria', 't +359 (0)2 9366449', 'f +359 (0)2 9367859', 'e office@solbulgaria.com', '', 0, '', 12, 'sol'),
(25, 21, 'SOL Deutschland', 'SOL Deutschland GmbH', '', 'Hafenstrasse 61-63', 'Krefeld', 'D-47809', 'Germany', 't +49 (0)2151 9580', 'f +49 (0)2151 958200', 'e gase@sol-group.de', 'www.sol-group.de', 0, '', 7, 'sol'),
(26, 21, 'SOL Deutschland', 'SOL Deutschland GmbH', '', 'Siemensstrasse 9', 'Gersthofen', 'D-86368', 'Germany', 't +49 (0)821 249230', 'f +49 (0)821 2492310', 'e info@tmg-s.de', 'www.tmg-s.de', 0, '', 7, 'sol'),
(27, 12, 'SOL France', 'SOL France Sas', '', '8 Rue du Compas - Z.I. des Béthunes', 'Saint Ouen L’Aumône', '95060', 'France', 't +33 (0)1 34 308660', 'f +33 (0)1 34 308661', '', 'www.solfrance.com', 0, '', 4, 'sol'),
(28, 54, 'SOL Gas Primari', 'SOL Gas Primari', '', 'Via Savona 100', 'Cuneo', '12100', 'Italy', '', '', '', '', 0, '', 1, 'sgp'),
(29, 54, 'SOL Gas Primari', 'SOL Gas Primari', '', 'Via G. Taliercio 14', 'Mantova', '46100', 'Italy', '', '', '', '', 0, '', 1, 'sgp'),
(30, 54, 'SOL Gas Primari', 'SOL Gas Primari', '', 'Via Firmio Leonzio 2', 'Salerno', '84100', 'Italy', '', '', '', '', 0, '', 1, 'sgp'),
(31, 54, 'SOL Gas Primari', 'SOL Gas Primari', '', 'Viale del Lavoro 12', 'San Martino Buon Albergo (VR) ', '37036', 'Italy', '', '', '', '', 0, '', 1, 'sgp'),
(32, 54, 'SOL Gas Primari', 'SOL Gas Primari', '', 'Via Baiona 154 ', 'Ravenna', '48100', 'Italy', '', '', '', '', 0, '', 1, 'sgp'),
(33, 35, 'SOL Hellas', 'SOL Hellas A.E.', 'Thessi Pachi Patima, Stefani Viotias', 'P.O.Box 3 ', '-  Magoula', '190 18', 'Greece', 't +30 (211) 10 23500', 'f +30 (211) 10 23598', 'e info@solhellas.gr', 'www.solhellas.gr', 0, '', 8, 'sol'),
(34, 40, 'SOL Hungary', 'SOL Hungary Kft', '', 'Faludi utca 3', 'Budapest', '1138', 'Hungary', 't +36 (0)6 309001036', '', 'e l.horvath@sol-tg.at', 'www.sol-hungary.hu', 0, '', 21, 'sol'),
(35, 53, 'SOL Kohlensäure', 'SOL Kohlensäure GmbH', '', 'Brohltalstraße 26', 'Burgbrohl', 'D-56659', 'Germany', 't  +49 (0)2636 5109 13', 'f +49 (0)2636 5109 30', 'e info@sks.solgroup.com', 'www.sks.solgroup.com', 0, '', 7, 'sks'),
(36, 11, 'SOL Nederland', 'SOL Nederland b.v.', '', 'Swaardvenstraat 11', 'AV Tilburg', '5048', 'Netherlands', 'T +31 (0)13 4625780', 'f +31 (0)13 4631181', 'e info@solnederland.nl', 'www.solnederland.nl', 0, '', 5, 'sol'),
(37, 13, 'SOL SEE', 'SOL SEE d.o.o.', '', 'Aco Šopov 80', 'Skopje', '1060', 'Macedonia', 't +389 (0)91 2031 411', 'f +389 (0)91 2032 354', '', '', 0, '', 9, 'sol'),
(38, 9, 'SOL Serbia', 'SOL Serbija d.o.o.', '', 'Industrijska zona bb', 'Nova Pazova', '22330', 'Serbia', 't +381 (0)22 328000', '', 'e office@sol.srbija.rs', '', 0, '', 14, 'sol'),
(39, 1, 'SOL SpA', 'SOL Spa', '', 'Via Borgazzi, 27', 'Monza', '20900', 'Italy', 't +39 (0)39 23961', 'f +39 (0)39 2396265', 'e dico@sol.it', 'www.sol.it', 0, 'C1000', 1, 'sol'),
(40, 51, 'SOL TK', 'SOL TK Teknik Gaz Sanayi Ve', '', 'Uskudar, Bahçelievler Mah.<br>Kaldirim Cad. No: 34/1', 'Çengelköy/Istanbul', '', 'Turkey', 't +90 (0)216 51009190', 'f +90 216 51009193', '', 'soltk.com.tr', 0, '', 22, 'sol'),
(41, 15, 'Sol Welding', '', '', '', '', '', '', '', '', '', '', 0, 'C3600', 1, 'solwelding'),
(42, 36, 'SOL-K', 'SOL-K Sh.p.k', '', 'Rexhep Mala 18', 'Pristina', '10000', 'Kosovo', 't +381 (0)38220588', '', '', '', 0, '', 17, 'sol'),
(43, 14, 'SOL-TG', 'SOL Technische Gase GmbH', '', 'Marie Curie Strasse 1', 'Wiener Neustadt', '2700', 'Austria', 't +43 (0)2622 89189', 'f +43 (0)2622 89189 21', '', 'www.sol-tg.at', 0, '', 6, 'sol'),
(44, 16, 'SPG', 'SPG - SOL GORENJSKA d.o.o.', '', 'Cesta železarjev 8', 'Jesenice', '4270', 'Slovenia', 't +386 (0)4 5833325', 'f +386 (0)4 5833328', 'e spg@spg-sol.si', 'www.spg-sol.si', 0, '', 2, 'spg'),
(45, 18, 'TGK', '', '', '', '', '', '', '', '', '', '', 0, '', 12, 'tgk'),
(46, 19, 'TGS', 'TGS Tehnicki Gasovi Skopje a.d.', '', 'Aco Šopov 80', 'Skopje', '1060', 'Macedonia', 't +389 (0)91 2031 411', 'f +389 (0)91 2032 354', '', 'www.tgs.com.mk', 0, 'C3000', 9, 'tgs'),
(47, 20, 'TGT', 'TGT a.d. Laktaši', '', 'Ulica Nikole Pašica, 28', 'Trn - RS BiH', '78252', 'Bosnia', 't +387 (0)51 584258/818', 'f +387 (0)51 584254', 'e tehnogas@inecco.net', '', 0, '', 13, ''),
(48, 20, 'TGT', 'TGP a.d.Petrovo', '“Tehnogas-Kakmuž” Kakmuž', 'Lugovi b.b.', 'Petrovo', '74317', 'Bosnia', 't +387 (0)53 793040', 'f +387 (0)53 797280', 'e tgp@zona.ba', '', 0, '', 13, ''),
(49, 22, 'TPJ', 'TPJ d.o.o. Jesenice', '', 'Cesta 1. maja 42', 'Jesenice', '4270', 'Slovenia', 't +386 (0)4 5833326', 'f +386 (0)4 5833328', 'e tpj@tpj.si', 'www.tpj.si', 0, 'C3200', 2, 'tpj'),
(50, 23, 'UTP', 'UTP d.o.o.', 'Uljanik tehnički plinovi<br>Sjedište', 'Sv. Polikarpa, 4', 'Pula', 'HR-52100', 'Croatia', 't +385 (0)52 214886', 'f +385 (0)52 215056', '', 'www.utp.hr', 0, 'C3100', 11, 'utp'),
(51, 49, 'VIVICARE', '', '', '', '', '', '', '', '', '', '', 0, '', 7, 'vivicare'),
(52, 24, 'VIVISOL Austria', '', '', '', '', '', '', '', '', '', '', 0, 'C6200', 6, 'vivisol'),
(53, 25, 'VIVISOL Belgium', '', '', '', '', '', '', '', '', '', '', 0, 'C6000', 3, 'vivisol'),
(54, 26, 'VIVISOL Calabria', '', '', '', '', '', '', '', '', '', '', 0, 'C5800', 1, 'vivisol'),
(55, 27, 'VIVISOL Deutschland', '', '', '', '', '', '', '', '', '', '', 0, 'C6600', 7, 'vivisol'),
(56, 28, 'VIVISOL France', '', '', '', '', '', '', '', '', '', '', 0, 'C6100', 4, 'vivisol'),
(57, 50, 'VIVISOL Hellas', '', '', '', '', '', '', '', '', '', '', 0, 'C6800', 8, 'vivisol'),
(58, 42, 'VIVISOL Ibérica', '', '', '', '', '', '', '', '', '', '', 0, 'C2900', 16, 'vivisol'),
(59, 29, 'VIVISOL Napoli', '', '', '', '', '', '', '', '', '', '', 0, 'C5100', 1, 'vivisol'),
(60, 31, 'VIVISOL Nederland', '', '', '', '', '', '', '', '', '', '', 0, 'C6300', 5, 'vivisol'),
(61, 30, 'VIVISOL Silarus', '', '', '', '', '', '', '', '', '', '', 0, 'C5300', 1, 'vivisol'),
(62, 2, 'VIVISOL srl', '', '', '', '', '', '', '', '', '', '', 0, 'C5000', 1, 'vivisol'),
(63, 44, 'VIVISOL TK', '', '', '', '', '', '', '', '', '', '', 0, '', 22, 'vivisol'),
(64, 33, 'VIVISOL Umbria', '', '', '', '', '', '', '', '', '', '', 0, 'C5700', 1, 'vivisol'),
(71, 58, 'SONOCARE', '', '', '', '', '', '', '', '', '', '', 0, '', 24, 'sonocare'),
(72, 101, 'SOL Kohlens', 'SOL Kohlens', '', 'Blumenstraße 5,', 'Geretsried', 'D-82538', 'Germany', '', '', '', '', 0, '', 7, 'SKS'),
(73, 102, 'SOL Spa - Feluy', 'SOL Spa', 'Stabilimento di Feluy', 'Zoning Industriel Feluy Zone B', 'Seneffe', 'B-7180', 'Belgium', '', '', '', '', 0, '', 3, 'sfy'),
(77, 106, 'SOL Spa - Frankfurt', 'SOL Spa', 'Stabilimento di Francoforte', 'Industriepark Höchst Gebäude G246', 'Frankfurt am Main', 'D-65926', 'Germany', '', '', '', '', 0, '', 7, 'SFF');

-- --------------------------------------------------------

--
-- Table structure for table `qui_company_old`
--

CREATE TABLE IF NOT EXISTS `qui_company_old` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `IDCompany` int(11) NOT NULL,
  `Company` varchar(100) NOT NULL,
  `denominazione` varchar(250) NOT NULL,
  `denominazione2` varchar(250) NOT NULL,
  `indirizzo` text NOT NULL,
  `localita` varchar(250) NOT NULL,
  `cap` varchar(8) NOT NULL,
  `nazione` varchar(50) NOT NULL,
  `tel` varchar(100) NOT NULL,
  `fax` varchar(100) NOT NULL,
  `mail` varchar(100) NOT NULL,
  `sito` varchar(100) NOT NULL,
  `Ordine` int(11) NOT NULL,
  `CodSAP` varchar(20) NOT NULL,
  `IDNazione` int(11) NOT NULL,
  `Prefisso` varchar(40) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=55 ;

--
-- Dumping data for table `qui_company_old`
--

INSERT INTO `qui_company_old` (`id`, `IDCompany`, `Company`, `denominazione`, `denominazione2`, `indirizzo`, `localita`, `cap`, `nazione`, `tel`, `fax`, `mail`, `sito`, `Ordine`, `CodSAP`, `IDNazione`, `Prefisso`) VALUES
(1, 49, 'VIVICARE', '', '', '', '', '', '', '', '', '', '', 0, '', 7, 'vivicare'),
(2, 1, 'SOL SpA', '', '', '', '', '', '', '', '', '', '', 0, 'C1000', 1, 'sol'),
(3, 2, 'VIVISOL srl', '', '', '', '', '', '', '', '', '', '', 0, 'C5000', 1, 'vivisol'),
(4, 3, 'Behringer srl', '', '', '', '', '', '', '', '', '', '', 0, 'C4500', 1, 'behringer'),
(5, 4, 'BTG', '', '', '', '', '', '', '', '', '', '', 0, 'C2100', 3, 'btg'),
(6, 5, 'France Oxygène', '', '', '', '', '', '', '', '', '', '', 0, '', 4, 'frox'),
(7, 6, 'GTS', '', '', '', '', '', '', '', '', '', '', 0, 'C3300', 15, 'gts'),
(8, 7, 'ICOA', '', '', '', '', '', '', '', '', '', '', 0, '', 1, 'icoa'),
(9, 8, 'Il Point', '', '', '', '', '', '', '', '', '', '', 0, 'C5950', 1, 'ilpoint'),
(10, 9, 'SOL Serbia', '', '', '', '', '', '', '', '', '', '', 0, '', 14, 'sol'),
(11, 10, 'KISIKANA', '', '', '', '', '', '', '', '', '', '', 0, '', 11, 'kisikana'),
(12, 11, 'SOL Nederland', '', '', '', '', '', '', '', '', '', '', 0, '', 5, 'sol'),
(13, 12, 'SOL France', '', '', '', '', '', '', '', '', '', '', 0, '', 4, 'sol'),
(14, 13, 'SOL SEE', '', '', '', '', '', '', '', '', '', '', 0, '', 9, 'sol'),
(15, 14, 'SOL-TG', '', '', '', '', '', '', '', '', '', '', 0, '', 6, 'sol'),
(16, 15, 'Sol Welding', '', '', '', '', '', '', '', '', '', '', 0, 'C3600', 1, 'solwelding'),
(17, 16, 'SPG', '', '', '', '', '', '', '', '', '', '', 0, '', 2, 'spg'),
(18, 17, 'SOL Bulgaria', '', '', '', '', '', '', '', '', '', '', 0, '', 12, 'sol'),
(19, 18, 'TGK', '', '', '', '', '', '', '', '', '', '', 0, '', 12, 'tgk'),
(20, 19, 'TGS', '', '', '', '', '', '', '', '', '', '', 0, 'C3000', 9, 'tgs'),
(21, 20, 'TGT', '', '', '', '', '', '', '', '', '', '', 0, '', 13, ''),
(22, 21, 'SOL Deutschland', '', '', '', '', '', '', '', '', '', '', 0, '', 7, 'sol'),
(23, 22, 'TPJ', '', '', '', '', '', '', '', '', '', '', 0, 'C3200', 2, 'tpj'),
(24, 23, 'UTP', '', '', '', '', '', '', '', '', '', '', 0, 'C3100', 11, 'utp'),
(25, 24, 'VIVISOL Austria', '', '', '', '', '', '', '', '', '', '', 0, 'C6200', 6, 'vivisol'),
(26, 25, 'VIVISOL Belgium', '', '', '', '', '', '', '', '', '', '', 0, 'C6000', 3, 'vivisol'),
(27, 26, 'VIVISOL Calabria', '', '', '', '', '', '', '', '', '', '', 0, 'C5800', 1, 'vivisol'),
(28, 27, 'VIVISOL Deutschland', '', '', '', '', '', '', '', '', '', '', 0, 'C6600', 7, 'vivisol'),
(29, 28, 'VIVISOL France', '', '', '', '', '', '', '', '', '', '', 0, 'C6100', 4, 'vivisol'),
(30, 29, 'VIVISOL Napoli', '', '', '', '', '', '', '', '', '', '', 0, 'C5100', 1, 'vivisol'),
(31, 30, 'VIVISOL Silarus', '', '', '', '', '', '', '', '', '', '', 0, 'C5300', 1, 'vivisol'),
(32, 31, 'VIVISOL Nederland', '', '', '', '', '', '', '', '', '', '', 0, 'C6300', 5, 'vivisol'),
(33, 33, 'VIVISOL Umbria', '', '', '', '', '', '', '', '', '', '', 0, 'C5700', 1, 'vivisol'),
(34, 35, 'SOL Hellas', '', '', '', '', '', '', '', '', '', '', 0, '', 8, 'sol'),
(35, 36, 'SOL-K', '', '', '', '', '', '', '', '', '', '', 0, '', 17, 'sol'),
(36, 37, 'ENERGETIKA', '', '', '', '', '', '', '', '', '', '', 0, '', 2, 'energetika'),
(37, 38, 'GTH', '', '', '', '', '', '', '', '', '', '', 0, '', 18, 'gth'),
(38, 39, 'SICGIL SOL', '', '', '', '', '', '', '', '', '', '', 0, '', 19, 'sicgilsol'),
(39, 40, 'SOL Hungary', '', '', '', '', '', '', '', '', '', '', 0, '', 21, 'sol'),
(40, 41, 'Dolby Medical', '', '', '', '', '', '', '', '', '', '', 0, 'C4400', 20, 'dolby'),
(41, 42, 'VIVISOL Ibérica', '', '', '', '', '', '', '', '', '', '', 0, 'C2900', 16, 'vivisol'),
(42, 43, 'BiotechSol', '', '', '', '', '', '', '', '', '', '', 0, '', 1, 'biotechsol'),
(43, 44, 'VIVISOL TK', '', '', '', '', '', '', '', '', '', '', 0, '', 22, 'vivisol'),
(44, 45, 'MEDES', '', '', '', '', '', '', '', '', '', '', 0, '', 1, 'medes'),
(45, 47, 'Diatheva', '', '', '', '', '', '', '', '', '', '', 0, 'C4700', 1, 'diatheva'),
(46, 48, 'CTS', '', '', '', '', '', '', '', '', '', '', 0, '', 1, 'cts'),
(47, 50, 'VIVISOL Hellas', '', '', '', '', '', '', '', '', '', '', 0, 'C6800', 8, 'vivisol'),
(48, 51, 'SOL TK', '', '', '', '', '', '', '', '', '', '', 0, '', 22, 'sol'),
(49, 52, 'BTG Gases', '', '', '', '', '', '', '', '', '', '', 0, 'C2105', 20, 'btg'),
(50, 53, 'SOL Kohlensäure', '', '', '', '', '', '', '', '', '', '', 0, '', 7, 'sks'),
(51, 54, 'SOL Gas Primari', '', '', '', '', '', '', '', '', '', '', 0, '', 1, 'sgp'),
(52, 55, 'Airsol', '', '', '', '', '', '', '', '', '', '', 0, '', 5, 'airsol'),
(53, 56, 'Flosit', '', '', '', '', '', '', '', '', '', '', 0, '', 23, 'flosit'),
(54, 57, 'Cryolab', '', '', '', '', '', '', '', '', '', '', 0, '', 1, 'cryolab');

-- --------------------------------------------------------

--
-- Table structure for table `qui_controlli_rda`
--

CREATE TABLE IF NOT EXISTS `qui_controlli_rda` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `timestamp_controllo` int(11) NOT NULL,
  `data_controllo` varchar(20) NOT NULL,
  `user_id` int(11) NOT NULL,
  `user_name` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=29 ;

--
-- Dumping data for table `qui_controlli_rda`
--

INSERT INTO `qui_controlli_rda` (`id`, `timestamp_controllo`, `data_controllo`, `user_id`, `user_name`) VALUES
(1, 1435789810, '01/07/2015 22:30:10', 10003, 'luigi'),
(11, 1438074330, '28.07.2015 09:05', 32, 'Alfredo Balconi'),
(12, 1439284558, '11.08.2015 09:15', 2038, 'Ketty Palumbo'),
(13, 1440495430, '25.08.2015 09:37', 325, 'Paolo Bartalini'),
(14, 1441706080, '08.09.2015 09:54', 0, ''),
(15, 1442915858, '22.09.2015 09:57', 620, 'Thierry Ferraro'),
(16, 1444125484, '06.10.2015 09:58', 1453, 'Francesco Esposito'),
(17, 1445335142, '20.10.2015 09:59', 272, 'Diego Cassini'),
(18, 1446545089, '03.11.2015 10:04', 1268, 'Francesca Leonesi'),
(19, 1447754741, '17.11.2015 10:05', 535, 'Riccardo Nava'),
(20, 1448964414, '01.12.2015 10:06', 1109, 'Andrea Fortunato'),
(21, 1450174121, '15.12.2015 10:08', 640, 'Vito Romito'),
(22, 1451384213, '29.12.2015 10:16', 0, ''),
(23, 1452594091, '12.01.2016 10:21', 303, 'Grazia Scotti'),
(24, 1453803811, '26.01.2016 10:23', 0, ''),
(25, 1455015208, '09.02.2016 10:53', 2056, 'Loris Fagioli'),
(26, 1456225385, '23.02.2016 11:03', 2468, 'Alessandro Cerri'),
(27, 1457435816, '08.03.2016 11:16', 583, 'Silvia Saini'),
(28, 1458645434, '22.03.2016 11:17', 2798, 'Stefano Truccero');

-- --------------------------------------------------------

--
-- Table structure for table `qui_costi_spedizioni`
--

CREATE TABLE IF NOT EXISTS `qui_costi_spedizioni` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `peso` int(4) NOT NULL,
  `zona1` int(8) NOT NULL,
  `zona2` int(8) NOT NULL,
  `zona3` int(8) NOT NULL,
  `zona4` int(8) NOT NULL,
  `zona5` int(8) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `qui_costi_spedizioni`
--

INSERT INTO `qui_costi_spedizioni` (`id`, `peso`, `zona1`, `zona2`, `zona3`, `zona4`, `zona5`) VALUES
(2, 10, 23, 27, 28, 45, 59),
(3, 30, 35, 39, 43, 60, 78),
(4, 60, 52, 57, 63, 83, 108),
(7, 100, 86, 95, 96, 115, 150),
(8, 200, 135, 148, 156, 215, 280);

-- --------------------------------------------------------

--
-- Table structure for table `qui_docs`
--

CREATE TABLE IF NOT EXISTS `qui_docs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_prodotto` int(11) NOT NULL,
  `documento` text NOT NULL,
  `precedenza` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `qui_flussi_extra`
--

CREATE TABLE IF NOT EXISTS `qui_flussi_extra` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `flusso` varchar(10) NOT NULL,
  `extra` varchar(20) NOT NULL,
  `extra_en` varchar(20) NOT NULL,
  `tab_extra_collegata` varchar(100) NOT NULL,
  `descrizione_it` text NOT NULL,
  `descrizione_en` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `qui_flussi_extra`
--

INSERT INTO `qui_flussi_extra` (`id`, `flusso`, `extra`, `extra_en`, `tab_extra_collegata`, `descrizione_it`, `descrizione_en`) VALUES
(1, 'bmc', 'cavo', '', 'qui_bmc_cavi', 'Quale cavo deve avere in dotazione?<br>\r\n<select name="cavo">\r\n*opzioni*\r\n</select>''', 'What kind of cable do you need?<br>\r\n<select name="cavo">\r\n*opzioni*\r\n</select>'''),
(2, 'bmc', 'lingua', 'language', 'qui_bmc_lingue', 'Lingua preimpostata nel dispositivo<br>\r\n<select name="lingua_impostata">\r\n*opzioni*\r\n</select>', 'Predertermined machine language<br>\r\n<select name="lingua_impostata">\r\n*opzioni*\r\n</select>'),
(3, 'htc', 'lingua', 'language', 'qui_bmc_lingue', 'Lingua preimpostata nel dispositivo<br>\r\n<select name="lingua_impostata">\r\n*opzioni*\r\n</select>', 'Predertermined machine language<br>\r\n<select name="lingua_impostata">\r\n*opzioni*\r\n</select>'),
(4, 'pre', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `qui_gruppo_merci`
--

CREATE TABLE IF NOT EXISTS `qui_gruppo_merci` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `coge` varchar(32) NOT NULL DEFAULT '',
  `gruppo_merce` varchar(32) NOT NULL DEFAULT '',
  `codice_sap` varchar(15) NOT NULL,
  `descrizione` text NOT NULL,
  `descrizione_en` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=33 ;

--
-- Dumping data for table `qui_gruppo_merci`
--

INSERT INTO `qui_gruppo_merci` (`id`, `coge`, `gruppo_merce`, `codice_sap`, `descrizione`, `descrizione_en`) VALUES
(19, 'N010', 'SG0090', 'Q0002', 'Cancelleria e stampati', 'Stationery and Printers'),
(20, 'N011', 'SG0030', 'Q0001', 'Materiali ausiliari e di consumo', 'Consumer and support products'),
(21, 'N012', 'SG0480', 'Q0005', 'Servizio macchine ufficio', 'Office Machine Service'),
(22, 'N013', 'SG0520', 'Q0006', 'Costi diversi del personale', 'Personnel various costs'),
(23, 'N014', 'SG0750', '', '', ''),
(24, 'N015', 'SG0200', 'Q0009', 'Manutenzione beni di proprietà', 'Own goods maintenance'),
(25, 'N016', 'SG0300', 'Q0004', 'Spese di rappresentanza', 'Spendings'),
(26, 'N017', 'SG0280', 'Q0003', 'Promozioni vendite', 'Sales promotion'),
(27, 'N018', 'SG0560', '', '', ''),
(28, 'N019', 'SG0530', 'Q0007', 'Dispositivi di protezione individuale', 'Security personal devices'),
(29, 'N020', 'SG0780', 'Q0008', 'Stampati AIC', 'AIC models'),
(30, '', 'SG0970', 'Q0010', 'Etichette ADR', 'ADR labels'),
(31, '', 'SG0520', 'Q0006', 'Costi diversi del personale', 'Personnel various costs');

-- --------------------------------------------------------

--
-- Table structure for table `qui_home`
--

CREATE TABLE IF NOT EXISTS `qui_home` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cod` varchar(5) NOT NULL,
  `contenuto` varchar(150) NOT NULL,
  `contenuto_en` varchar(100) NOT NULL,
  `contenuto_default` varchar(100) NOT NULL,
  `link` varchar(300) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=21 ;

--
-- Dumping data for table `qui_home`
--

INSERT INTO `qui_home` (`id`, `cod`, `contenuto`, `contenuto_en`, `contenuto_default`, `link`) VALUES
(1, 'A1', 'img home-1A-2016.jpg', 'img home-1A-2016-en.jpg', 'img home-1A.jpg', 'http://192.168.60.157/quice_staging/ricerca_prodotti.php?categoria1=Pubblicazioni_Solgroup&categoria2=Pubblicazioni_Sol&paese=&negozio=consumabili'),
(2, 'A2', '', '', 'img home-2A.jpg', ''),
(3, 'A3', '', '', 'img home-3A.jpg', ''),
(4, 'A4', '', '', 'prodotti_home_GIF-A4.gif', ''),
(5, 'A5', '', '', 'img home-5A.jpg', ''),
(6, 'B1', 'img home-B1-2016.jpg', 'img home-B1-2016-en.jpg', 'img home-1B.jpg', 'http://192.168.60.157/quice_staging/ricerca_prodotti.php?categoria1=Pubblicazioni_Solgroup&categoria2=Pubblicazioni_Sol&paese=&negozio=consumabili'),
(7, 'B2', 'img home-B2-2016.jpg', 'img home-B2-2016-en.jpg', 'prodotti_home_GIF-B2.gif', 'http://192.168.60.157/quice_staging/ricerca_prodotti.php?categoria1=Pubblicazioni_Solgroup&categoria2=Pubblicazioni_Sol&paese=&negozio=consumabili'),
(8, 'B3', '', '', 'img home-3B.jpg', ''),
(9, 'B4', '', '', 'prodotti_home_GIF-B4.gif', ''),
(10, 'B5', '', '', 'img home-5B.jpg', ''),
(11, 'C1', '', '', 'img home-1C.jpg', ''),
(12, 'C2', '', '', 'img home-2C.jpg', ''),
(13, 'C3', '', '', 'prodotti_home_GIF-C3.gif', 'http://192.168.60.157/quice_staging/ricerca_prodotti.php?categoria1=Etichette_generiche_e_collari&categoria2=Collari_e_accessori&paese=Italy&negozio=labels'),
(14, 'C4', '', '', 'img home-4C.jpg', ''),
(15, 'C5', '', '', 'img home-5C.jpg', ''),
(16, 'D1', '', '', 'img home-1D.jpg', ''),
(17, 'D2', '', '', 'prodotti_home_GIF-D2.gif', ''),
(18, 'D3', '', '', 'img home-3D.jpg', ''),
(19, 'D4', '', '', 'img home-4D.jpg', ''),
(20, 'D5', '', '', 'img home-5D.jpg', '');

-- --------------------------------------------------------

--
-- Table structure for table `qui_indirizzi_avviso`
--

CREATE TABLE IF NOT EXISTS `qui_indirizzi_avviso` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `codice_attivita` varchar(20) NOT NULL,
  `negozio` varchar(30) NOT NULL,
  `mail` varchar(60) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `qui_indirizzi_avviso`
--

INSERT INTO `qui_indirizzi_avviso` (`id`, `codice_attivita`, `negozio`, `mail`) VALUES
(1, 'lab', 'labels', 'luigi.riva@dtpc.it'),
(2, 'lab', 'labels', 'mara.girardi@publiem.it'),
(3, 'ass', 'assets', 'luigi.riva@publiem.it'),
(4, 'con', 'consumabili', 'luigi.riva@publiem.it'),
(5, 'spa', 'spare_parts', 'luigi.riva@publiem.it'),
(6, 'viv', 'vivilist', 'luigi.riva@publiem.it');

-- --------------------------------------------------------

--
-- Table structure for table `qui_lingue`
--

CREATE TABLE IF NOT EXISTS `qui_lingue` (
  `idioma` tinytext NOT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lang` tinytext NOT NULL,
  `desc` text NOT NULL,
  `attiva` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=26 ;

--
-- Dumping data for table `qui_lingue`
--

INSERT INTO `qui_lingue` (`idioma`, `id`, `lang`, `desc`, `attiva`) VALUES
('it', 1, 'it', 'Italiano', 1),
('it', 2, 'en', 'Inglese', 1),
('it', 3, 'fr', 'Francese', 0),
('it', 4, 'de', 'Tedesco', 0),
('it', 5, 'es', 'Spagnolo', 0),
('en', 6, 'it', 'Italian', 1),
('en', 7, 'en', 'English', 1),
('en', 8, 'fr', 'French', 0),
('en', 9, 'de', 'German', 0),
('en', 10, 'es', 'Spanish', 0),
('fr', 11, 'it', 'Italien', 0),
('fr', 12, 'en', 'Anglais', 0),
('fr', 13, 'de', 'Aleman', 0),
('fr', 14, 'es', 'Spagnol', 0),
('de', 15, 'it', 'Italienish', 0),
('de', 16, 'en', 'English', 0),
('fr', 17, 'fr', 'Français', 0),
('de', 18, 'de', 'Deutsch', 0),
('de', 19, 'fr', 'Franzosisch', 0),
('de', 20, 'es', 'Spanish', 0),
('es', 21, 'it', 'Itàliano', 0),
('es', 22, 'en', 'Inglés', 0),
('es', 23, 'fr', 'Francés', 0),
('es', 24, 'de', 'Alemano', 0),
('es', 25, 'es', 'Espagnol', 0);

-- --------------------------------------------------------

--
-- Table structure for table `qui_messaggi_carrello`
--

CREATE TABLE IF NOT EXISTS `qui_messaggi_carrello` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `categoria` varchar(50) NOT NULL,
  `ric_mag` varchar(8) NOT NULL,
  `testo_it` text NOT NULL,
  `testo_en` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `qui_messaggi_carrello`
--

INSERT INTO `qui_messaggi_carrello` (`id`, `categoria`, `ric_mag`, `testo_it`, `testo_en`) VALUES
(1, '', 'RIC', 'Prodotto non disponibile a magazzino.<br>\r\nEvasione ordine in circa un mese.', 'Not available.<br>Delivery in one month.'),
(2, '', 'MAG', 'Prodotto normalmente disponibile in una settimana.', 'Normally available in a week.'),
(3, '', 'PUB', 'Prodotto non disponibile a magazzino.<br>\r\nEvasione ordine in circa una settimana.', 'Not available.<br>Delivery in a week.'),
(4, '', 'maglab', 'Prodotto normalmente disponibile in una settimana.', 'Normally available in a week.');

-- --------------------------------------------------------

--
-- Table structure for table `qui_nations`
--

CREATE TABLE IF NOT EXISTS `qui_nations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nazione` varchar(100) NOT NULL,
  `sigla` varchar(4) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=45 ;

--
-- Dumping data for table `qui_nations`
--

INSERT INTO `qui_nations` (`id`, `nazione`, `sigla`) VALUES
(1, 'France', 'fr'),
(2, 'Albania', 'al'),
(3, 'Austria', 'at'),
(4, 'Belgium', 'be'),
(5, 'Bosnia and Herzegovina', 'ba'),
(6, 'Bulgaria', 'bg'),
(7, 'Croatia', 'hr'),
(8, 'Germany', 'de'),
(9, 'Greece', 'gr'),
(10, 'Hungary', 'hu'),
(11, 'Italy', 'it'),
(12, 'Kosovo', 'kv'),
(13, 'Macedonia', 'mk'),
(14, 'Netherlands', 'nl'),
(15, 'Romania', 'ro'),
(16, 'Serbia', 'rs'),
(17, 'Slovenia', 'si'),
(18, 'Spain', 'es'),
(19, 'Turkey', 'tr'),
(20, 'United Kingdom', 'gb'),
(21, 'Russia', 'ru'),
(22, 'Ireland', 'ie'),
(23, 'Denmark', 'dk'),
(24, 'Ukraine', 'ua'),
(25, 'Norway', 'no'),
(26, 'Sweden', 'se'),
(27, 'Belarus', 'by'),
(28, 'Poland', 'pl'),
(29, 'Montenegro', 'me'),
(30, 'Slovakia', 'sk'),
(31, 'Andorra', 'ad'),
(32, 'Luxembourg', 'lu'),
(33, 'Lithuania', 'lt'),
(34, 'Switzerland', 'ch'),
(35, 'Vatican', 'va'),
(36, 'Czech Republic', 'cz'),
(37, 'San Marino', 'sm'),
(38, 'Moldova', 'md'),
(39, 'Faoe Islands', 'fo'),
(40, 'Estonia', 'ee'),
(41, 'Malta', 'mt'),
(42, 'Finland', 'fi'),
(43, 'Cyprus', 'cy'),
(44, 'Latvia', 'lv');

-- --------------------------------------------------------

--
-- Table structure for table `qui_pharma_quant_prezzi`
--

CREATE TABLE IF NOT EXISTS `qui_pharma_quant_prezzi` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tipologia` varchar(25) NOT NULL,
  `tipologia_tx` varchar(40) NOT NULL,
  `quant` int(11) NOT NULL,
  `prezzo` float(8,2) NOT NULL,
  `prezzo_unitario` float(8,3) NOT NULL,
  `coefficiente` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=194 ;

--
-- Dumping data for table `qui_pharma_quant_prezzi`
--

INSERT INTO `qui_pharma_quant_prezzi` (`id`, `tipologia`, `tipologia_tx`, `quant`, `prezzo`, `prezzo_unitario`, `coefficiente`) VALUES
(153, 'BL_210x297_old', 'blocchi_210x297', 100, 100.00, 0.000, 16),
(2, 'Mod_laser', 'Mod laser', 1, 2.00, 2.000, 0),
(3, 'L_287x100', 'L_287x100', 200, 510.00, 0.000, 60),
(4, 'L_287x100', 'L_287x100', 500, 690.00, 0.000, 37),
(5, 'L_287x100', 'L_287x100', 1000, 875.00, 0.000, 42),
(6, 'L_287x100', 'L_287x100', 2000, 1290.00, 0.000, 29),
(7, 'L_287x100', 'L_287x100', 5000, 2170.00, 0.000, 26),
(8, 'L_287x100', 'L_287x100', 10000, 3450.00, 0.000, 0),
(11, 'L_287x120', 'L_287x120', 200, 540.00, 0.000, 70),
(12, 'L_287x120', 'L_287x120', 500, 750.00, 0.000, 40),
(13, 'L_287x120', 'L_287x120', 1000, 950.00, 0.000, 45),
(14, 'L_287x120', 'L_287x120', 2000, 1395.00, 0.000, 32),
(15, 'L_287x120', 'L_287x120', 5000, 2340.00, 0.000, 29),
(16, 'L_287x120', 'L_287x120', 10000, 3780.00, 0.000, 0),
(19, 'L_140x55', 'L_140x55', 200, 280.00, 0.000, 14),
(20, 'L_140x55', 'L_140x55', 500, 320.00, 0.000, 12),
(21, 'L_140x55', 'L_140x55', 1000, 385.00, 0.000, 10),
(22, 'L_140x55', 'L_140x55', 2000, 480.00, 0.000, 7),
(23, 'L_140x55', 'L_140x55', 5000, 680.00, 0.000, 4),
(24, 'L_140x55', 'L_140x55', 10000, 880.00, 0.000, 0),
(27, 'L_176x65', 'L_176x65', 200, 320.00, 0.000, 13),
(28, 'L_176x65', 'L_176x65', 500, 360.00, 0.000, 12),
(29, 'L_176x65', 'L_176x65', 1000, 420.00, 0.000, 14),
(30, 'L_176x65', 'L_176x65', 2000, 560.00, 0.000, 9),
(31, 'L_176x65', 'L_176x65', 5000, 820.00, 0.000, 6),
(32, 'L_176x65', 'L_176x65', 10000, 1100.00, 0.000, 0),
(35, 'L_200x72', 'L_200x72', 200, 400.00, 0.000, 24),
(36, 'L_200x72', 'L_200x72', 500, 470.00, 0.000, 18),
(37, 'L_200x72', 'L_200x72', 1000, 560.00, 0.000, 6),
(38, 'L_200x72', 'L_200x72', 2000, 620.00, 0.000, 10),
(39, 'L_200x72', 'L_200x72', 5000, 920.00, 0.000, 7),
(40, 'L_200x72', 'L_200x72', 10000, 1280.00, 0.000, 0),
(43, 'L_160x160', 'L_160x160', 200, 420.00, 0.000, 30),
(44, 'L_160x160', 'L_160x160', 500, 510.00, 0.000, 26),
(45, 'L_160x160', 'L_160x160', 1000, 640.00, 0.000, 32),
(46, 'L_160x160', 'L_160x160', 2000, 960.00, 0.000, 20),
(47, 'L_160x160', 'L_160x160', 5000, 1560.00, 0.000, 11),
(48, 'L_160x160', 'L_160x160', 10000, 0.00, 0.000, 0),
(51, 'L_300x160', 'L_300x160', 200, 0.00, 0.000, 0),
(52, 'L_300x160', 'L_300x160', 500, 0.00, 0.000, 0),
(53, 'L_300x160', 'L_300x160', 1000, 960.00, 0.000, 0),
(54, 'L_300x160', 'L_300x160', 2000, 0.00, 0.000, 0),
(55, 'L_300x160', 'L_300x160', 5000, 2120.00, 0.000, 0),
(56, 'L_300x160', 'L_300x160', 10000, 0.00, 0.000, 0),
(60, 'PL_210x297', 'PL_210x297', 200, 503.40, 0.000, 64),
(61, 'PL_210x297', 'PL_210x297', 1000, 1017.00, 0.000, 94),
(62, 'PL_210x297', 'PL_210x297', 2000, 1961.25, 0.000, 53),
(63, 'PL_210x297', 'PL_210x297', 5000, 3547.50, 0.000, 60),
(64, 'PL_210x297', 'PL_210x297', 10000, 6570.00, 0.000, 0),
(67, 'PL_420x297', 'PL_420x297', 200, 557.40, 0.000, 102),
(68, 'PL_420x297', 'PL_420x297', 500, 861.00, 0.000, 64),
(69, 'PL_420x297', 'PL_420x297', 1000, 1182.00, 0.000, 106),
(70, 'PL_420x297', 'PL_420x297', 2000, 2242.50, 0.000, 53),
(71, 'PL_420x297', 'PL_420x297', 5000, 3810.00, 0.000, 64),
(72, 'PL_420x297', 'PL_420x297', 10000, 7020.00, 0.000, 0),
(75, 'PL_630x297', 'PL_630x297', 200, 747.90, 0.000, 90),
(76, 'PL_630x297', 'PL_630x297', 500, 1018.50, 0.000, 78),
(77, 'PL_630x297', 'PL_630x297', 1000, 1410.00, 0.000, 107),
(78, 'PL_630x297', 'PL_630x297', 2000, 2478.75, 0.000, 62),
(79, 'PL_630x297', 'PL_630x297', 5000, 4327.50, 0.000, 71),
(80, 'PL_630x297', 'PL_630x297', 10000, 7875.00, 0.000, 0),
(83, 'PL_840x370', 'PL_840x370', 200, 1211.40, 0.000, 91),
(84, 'PL_840x370', 'PL_840x370', 500, 1483.50, 0.000, 87),
(85, 'PL_840x370', 'PL_840x370', 1000, 1917.00, 0.000, 138),
(86, 'PL_840x370', 'PL_840x370', 2000, 3292.50, 0.000, 68),
(87, 'PL_840x370', 'PL_840x370', 5000, 5347.50, 0.000, 85),
(88, 'PL_840x370', 'PL_840x370', 10000, 9585.00, 0.000, 0),
(91, 'PL_840x440', 'PL_840x440', 200, 1218.30, 0.000, 94),
(92, 'PL_840x440', 'PL_840x440', 500, 1499.25, 0.000, 93),
(93, 'PL_840x440', 'PL_840x440', 1000, 1962.00, 0.000, 143),
(94, 'PL_840x440', 'PL_840x440', 2000, 3397.50, 0.000, 72),
(95, 'PL_840x440', 'PL_840x440', 5000, 5572.50, 0.000, 90),
(96, 'PL_840x440', 'PL_840x440', 10000, 10035.00, 0.000, 0),
(99, 'PL_630_210', 'PL_630+210', 200, 1123.50, 0.000, 125),
(100, 'PL_630_210', 'PL_630+210', 500, 1499.25, 0.000, 84),
(101, 'PL_630_210', 'PL_630+210', 1000, 1914.00, 0.000, 129),
(102, 'PL_630_210', 'PL_630+210', 2000, 3208.13, 0.000, 69),
(103, 'PL_630_210', 'PL_630+210', 5000, 5253.75, 0.000, 83),
(104, 'PL_630_210', 'PL_630_210', 10000, 9435.00, 0.000, 0),
(107, 'PL_840_210', 'PL_840+210', 200, 1577.40, 0.000, 107),
(108, 'PL_840_210', 'PL_840+210', 500, 1897.50, 0.000, 102),
(109, 'PL_840_210', 'PL_840+210', 1000, 2407.50, 0.000, 158),
(110, 'PL_840_210', 'PL_840+210', 2000, 3988.13, 0.000, 81),
(111, 'PL_840_210', 'PL_840+210', 5000, 6416.25, 0.000, 97),
(112, 'PL_840_210', 'PL_840+210', 10000, 11250.00, 0.000, 0),
(115, 'PL_630_210_210', 'PL_630+210+210', 200, 1482.60, 0.000, 139),
(116, 'PL_630_210_210', 'PL_630+210+210', 500, 1897.50, 0.000, 92),
(117, 'PL_630_210_210', 'PL_630+210+210', 1000, 2359.50, 0.000, 144),
(118, 'PL_630_210_210', 'PL_630+210+210', 2000, 3798.75, 0.000, 77),
(119, 'PL_630_210_210', 'PL_630+210+210', 5000, 6097.50, 0.000, 91),
(120, 'PL_630_210_210', 'PL_630+210+210', 10000, 10650.00, 0.000, 0),
(123, 'PL_neutro', 'PL_neutro', 200, 64.00, 0.000, 0),
(124, 'PL_neutro', 'PL_neutro', 500, 160.00, 0.000, 0),
(125, 'PL_neutro', 'PL_neutro', 1000, 320.00, 0.000, 0),
(126, 'PL_neutro', 'PL_neutro', 2000, 640.00, 0.000, 0),
(127, 'PL_neutro', 'PL_neutro', 5000, 1600.00, 0.000, 0),
(128, 'PL_neutro', 'PL_neutro', 10000, 3200.00, 0.000, 0),
(131, 'Med_AIC_0.41', 'medicali e AIC aggiunte da consum 0.41', 1, 0.41, 0.410, 0),
(132, 'Med_AIC_0.41', 'medicali e AIC aggiunte da consum 0.41', 500, 205.00, 0.410, 0),
(133, 'Med_AIC_5.00', 'medicali e AIC aggiunte da consum 5.00', 1, 5.00, 5.000, 0),
(134, 'Med_AIC_5.00', 'medicali e AIC aggiunte da consum 5.00', 500, 2500.00, 5.000, 0),
(135, 'Med_AIC_7.00', 'medicali e AIC aggiunte da consum 7.00', 1, 7.00, 7.000, 0),
(136, 'Med_AIC_7.00', 'medicali e AIC aggiunte da consum 7.00', 500, 3500.00, 7.000, 0),
(137, 'Med_AIC_7.50', 'medicali e AIC aggiunte da consum 7.50', 1, 7.50, 7.500, 0),
(138, 'Med_AIC_7.50', 'medicali e AIC aggiunte da consum 7.50', 500, 3750.00, 7.500, 0),
(139, 'Med_AIC_1.00', 'medicali e AIC aggiunte da consum 1.00', 1, 1.00, 1.000, 0),
(140, 'Med_AIC_1.00', 'medicali e AIC aggiunte da consum 1.00', 500, 500.00, 1.000, 0),
(141, 'Med_AIC_2.80', 'medicali e AIC aggiunte da consum 2.80', 1, 2.80, 2.800, 0),
(142, 'Med_AIC_2.80', 'medicali e AIC aggiunte da consum 2.80', 500, 1400.00, 2.800, 0),
(143, 'Med_AIC_12.00', 'medicali e AIC aggiunte da consum 12.00', 1, 12.00, 12.000, 0),
(144, 'Med_AIC_12.00', 'medicali e AIC aggiunte da consum 12.00', 500, 6000.00, 12.000, 0),
(145, 'Med_AIC_26.00', 'medicali e AIC aggiunte da consum 26.00', 1, 26.00, 26.000, 0),
(146, 'Med_AIC_26.00', 'medicali e AIC aggiunte da consum 26.00', 500, 13000.00, 26.000, 0),
(147, 'Med_AIC_30.00', 'medicali e AIC aggiunte da consum 30.00', 1, 30.00, 30.000, 0),
(148, 'Med_AIC_30.00', 'medicali e AIC aggiunte da consum 30.00', 500, 15000.00, 30.000, 0),
(149, 'Med_AIC_35.60', 'medicali e AIC aggiunte da consum 35.60', 1, 35.60, 35.600, 0),
(150, 'Med_AIC_35.60', 'medicali e AIC aggiunte da consum 35.60', 500, 17800.00, 35.600, 0),
(151, 'Med_AIC_48.30', 'medicali e AIC aggiunte da consum 48.30', 1, 48.30, 48.300, 0),
(152, 'Med_AIC_48.30', 'medicali e AIC aggiunte da consum 48.30', 500, 24150.00, 48.300, 0),
(154, 'BL_210x297_old', 'blocchi_210x297', 1000, 240.00, 0.000, 11),
(155, 'BL_210x297_old', 'blocchi_210x297', 2500, 400.00, 0.000, 11),
(156, 'BL_210x297_old', 'blocchi_210x297', 5000, 690.00, 0.000, 9),
(157, 'BL_210x297_old', 'blocchi_210x297', 10000, 1100.00, 0.000, 0),
(160, 'L_CAP_PROXY', 'L_CAP_PROXY', 1000, 650.00, 0.000, 0),
(159, 'L_CAP_PROXY', 'L_CAP_PROXY', 500, 470.00, 0.000, 36),
(158, 'L_CAP_PROXY', 'L_CAP_PROXY', 200, 360.00, 0.000, 37),
(161, 'PL_210x297', 'PL_210x297', 500, 690.00, 0.000, 65),
(162, 'L_200x94', 'L_200x94', 200, 400.00, 0.000, 50),
(163, 'L_200x94', 'L_200x94', 500, 550.00, 0.000, 24),
(164, 'L_200x94', 'L_200x94', 1000, 670.00, 0.000, 37),
(165, 'L_200x94', 'L_200x94', 2000, 1040.00, 0.000, 21),
(166, 'L_200x94', 'L_200x94', 5000, 1660.00, 0.000, 21),
(167, 'L_200x94', 'L_200x94', 10000, 2730.00, 0.000, 0),
(168, 'L_CAP_PROXY_OLD', 'L_CAP_PROXY_OLD', 200, 530.00, 0.000, 50),
(169, 'L_CAP_PROXY_OLD', 'L_CAP_PROXY_OLD', 500, 470.00, 0.000, 56),
(170, 'L_CAP_PROXY_OLD', 'L_CAP_PROXY_OLD', 1000, 650.00, 0.000, 0),
(171, 'PL_630x370', 'PL_630x370', 200, 764.00, 0.000, 113),
(172, 'PL_630x370', 'PL_630x370', 500, 1103.00, 0.000, 73),
(173, 'PL_630x370', 'PL_630x370', 1000, 1468.00, 0.000, 115),
(174, 'PL_630x370', 'PL_630x370', 2000, 2618.00, 0.000, 60),
(175, 'PL_630x370', 'PL_630x370', 5000, 4418.00, 0.000, 76),
(176, 'PL_630x370', 'PL_630x370', 10000, 8218.00, 0.000, 0),
(177, 'BL_210x297', 'blocchi_210x297', 200, 190.00, 0.000, 17),
(178, 'BL_210x297', 'blocchi_210x297', 500, 200.00, 0.000, 8),
(179, 'BL_210x297', 'blocchi_210x297', 1000, 240.00, 0.000, 8),
(180, 'BL_210x297', 'blocchi_210x297', 2000, 380.00, 0.000, 9),
(181, 'BL_210x297', 'blocchi_210x297', 5000, 680.00, 0.000, 9),
(182, 'BL_210x297', 'blocchi_210x297', 10000, 1130.00, 0.000, 0),
(183, 'BL_420x297', 'blocchi_420x297', 200, 285.00, 0.000, 25),
(184, 'BL_420x297', 'blocchi_420x297', 500, 323.00, 0.000, 12),
(185, 'BL_420x297', 'blocchi_420x297', 1000, 395.00, 0.000, 12),
(186, 'BL_420x297', 'blocchi_420x297', 2000, 620.00, 0.000, 13),
(187, 'BL_420x297', 'blocchi_420x297', 5000, 1100.00, 0.000, 13),
(188, 'BL_420x297', 'blocchi_420x297', 10000, 1820.00, 0.000, 0),
(189, 'L_140x55_mag', 'L_140x55_mag', 1, 0.14, 0.000, 0),
(190, 'L_160x160_mag', 'L_160x160_mag', 1, 0.32, 0.000, 0),
(191, 'L_176x65_mag', 'L_176x65_mag', 1, 0.18, 0.000, 0),
(192, 'L_200x72_mag', 'L_200x72_mag', 1, 0.32, 0.000, 0),
(193, 'L_300x160_mag', 'L_300x160_mag', 1, 0.50, 0.000, 0);

-- --------------------------------------------------------

--
-- Table structure for table `qui_proposte_prodotti`
--

CREATE TABLE IF NOT EXISTS `qui_proposte_prodotti` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `obsoleto` tinyint(1) NOT NULL,
  `negozio` tinytext NOT NULL,
  `paese` tinytext NOT NULL,
  `categoria1_it` tinytext NOT NULL,
  `categoria2_it` tinytext NOT NULL,
  `categoria3_it` tinytext NOT NULL,
  `categoria4_it` tinytext NOT NULL,
  `extra` tinytext NOT NULL,
  `descrizione1_it` text NOT NULL,
  `descrizione2_it` text NOT NULL,
  `descrizione3_it` text NOT NULL,
  `descrizione4_it` text NOT NULL,
  `id_valvola` tinytext NOT NULL,
  `id_cappellotto` tinytext NOT NULL,
  `id_pescante` tinytext NOT NULL,
  `codice_art` tinytext NOT NULL,
  `cf` tinytext NOT NULL,
  `codice_numerico` tinytext NOT NULL,
  `gruppo_merci` tinytext NOT NULL,
  `coge` tinytext NOT NULL,
  `wbs` tinytext NOT NULL,
  `prezzo` float(14,2) NOT NULL,
  `confezione` tinytext NOT NULL,
  `foto` text NOT NULL,
  `foto_gruppo` text NOT NULL,
  `foto_famiglia` text NOT NULL,
  `icona` text NOT NULL,
  `rif_famiglia` text NOT NULL,
  `precedenza` int(11) NOT NULL,
  `categoria1_en` tinytext NOT NULL,
  `categoria2_en` tinytext NOT NULL,
  `categoria3_en` tinytext NOT NULL,
  `categoria4_en` tinytext NOT NULL,
  `descrizione1_en` text NOT NULL,
  `descrizione2_en` text NOT NULL,
  `descrizione3_en` text NOT NULL,
  `descrizione4_en` text NOT NULL,
  `filepath` text NOT NULL,
  `ordine_stampa` tinyint(1) NOT NULL,
  `switch_lista_radio` tinyint(1) NOT NULL,
  `id_proponente` int(11) NOT NULL,
  `mail_proponente` text NOT NULL,
  `id_resp` int(11) NOT NULL,
  `mail_resp` text NOT NULL,
  `livello_approvazione` tinyint(1) NOT NULL,
  `approvato_da` varchar(30) NOT NULL,
  `ultima_modifica` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `qui_proposte_prodotti`
--

INSERT INTO `qui_proposte_prodotti` (`id`, `obsoleto`, `negozio`, `paese`, `categoria1_it`, `categoria2_it`, `categoria3_it`, `categoria4_it`, `extra`, `descrizione1_it`, `descrizione2_it`, `descrizione3_it`, `descrizione4_it`, `id_valvola`, `id_cappellotto`, `id_pescante`, `codice_art`, `cf`, `codice_numerico`, `gruppo_merci`, `coge`, `wbs`, `prezzo`, `confezione`, `foto`, `foto_gruppo`, `foto_famiglia`, `icona`, `rif_famiglia`, `precedenza`, `categoria1_en`, `categoria2_en`, `categoria3_en`, `categoria4_en`, `descrizione1_en`, `descrizione2_en`, `descrizione3_en`, `descrizione4_en`, `filepath`, `ordine_stampa`, `switch_lista_radio`, `id_proponente`, `mail_proponente`, `id_resp`, `mail_resp`, `livello_approvazione`, `approvato_da`, `ultima_modifica`) VALUES
(1, 0, '1', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0.00, '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', 0, 0, 0, '', 0, '', 0, '', '2013-07-30 07:59:33'),
(2, 0, 'assets', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0.00, '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', 0, 0, 32, 'a.balconi@sol.it', 161, 'd.cassini@sol.it', 1, '', '2013-08-01 12:02:51'),
(3, 0, 'consumabili', 'Consumabili', '', '', '', '', '', 'tgjhj,ml', 'khbjknm,', '', '', '', '', '', '', '', '', 'SG0530', '', '', 8.00, '10', '', '', '', '', '', 0, '', '', '', '', 'hjbknm,', 'jklò', '', '', '', 0, 0, 32, 'a.balconi@sol.it', 161, 'd.cassini@sol.it', 1, '', '2013-08-01 13:42:05');

-- --------------------------------------------------------

--
-- Table structure for table `qui_RdF`
--

CREATE TABLE IF NOT EXISTS `qui_RdF` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_unita` int(11) NOT NULL,
  `nome_unita` tinytext NOT NULL,
  `id_company` int(11) NOT NULL,
  `nome_company` varchar(100) NOT NULL,
  `id_resp` int(11) NOT NULL,
  `nome_resp` text NOT NULL,
  `id_operatore` int(11) NOT NULL,
  `nome_operatore` text NOT NULL,
  `totale_RdF` float(14,2) NOT NULL,
  `data_ordine` int(11) NOT NULL,
  `data_fattura` int(11) NOT NULL,
  `data_ultima_modifica` int(11) NOT NULL,
  `n_ord_sap` varchar(20) NOT NULL,
  `n_fatt_sap` varchar(20) NOT NULL,
  `flag_fatturata` tinyint(1) NOT NULL,
  `logo` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=73 ;

--
-- Dumping data for table `qui_RdF`
--

INSERT INTO `qui_RdF` (`id`, `id_unita`, `nome_unita`, `id_company`, `nome_company`, `id_resp`, `nome_resp`, `id_operatore`, `nome_operatore`, `totale_RdF`, `data_ordine`, `data_fattura`, `data_ultima_modifica`, `n_ord_sap`, `n_fatt_sap`, `flag_fatturata`, `logo`) VALUES
(1, 93, 'VIV NA', 29, 'VIVISOL Napoli', 341, 'Lucio Di Franco', 473, 'Nicoletta Susanna Canegrati', 273.70, 1455199914, 1456821126, 1456821126, '70049963', '5016700013', 0, 'vivisol'),
(2, 313, 'VIV I', 42, 'VIVISOL Ibérica', 1510, 'Enrico Attilio Spiaggi', 473, 'Nicoletta Susanna Canegrati', 252.00, 1455200293, 1456821233, 1456821233, '70049961', '5016100180', 0, 'vivisol'),
(3, 102, 'VIV CAL', 26, 'VIVISOL Calabria', 216, 'Filippo Palmieri', 473, 'Nicoletta Susanna Canegrati', 1763.14, 1455200447, 1456820849, 1456820849, '70049958', '5016700015', 0, 'vivisol'),
(4, 175, 'VIV A', 24, 'VIVISOL Austria', 655, 'Mirco Lazzarini', 473, 'Nicoletta Susanna Canegrati', 33.60, 1455200552, 1456820862, 1456820862, '70049956', '5016100181', 0, 'vivisol'),
(5, 52, 'CGO TO', 1, 'SOL SpA', 7, 'Mirco Lazzarini', 473, 'Nicoletta Susanna Canegrati', 788.00, 1455200552, 1456820876, 1456820876, '70049953', '5016700014', 0, 'vivisol'),
(6, 53, 'SCN', 54, 'SOL Gas Primari', 105, 'Cesare Mazzaferri', 473, 'Nicoletta Susanna Canegrati', 327.60, 1455200552, 1455266377, 1455266377, '70049931', '1016700019', 0, 'sol'),
(7, 60, 'SVR', 54, 'SOL Gas Primari', 202, 'Fabrizio Pagani', 473, 'Nicoletta Susanna Canegrati', 1702.60, 1455200552, 1455266365, 1455266365, '70049925', '1016700018', 0, 'sol'),
(8, 165, 'SOL-TG', 14, 'SOL-TG', 651, 'Johannes Hassler', 473, 'Nicoletta Susanna Canegrati', 210.00, 1455200552, 1455266403, 1455266403, '70049919', '1016100454', 0, 'sol'),
(9, 156, 'SOL NL', 11, 'SOL Nederland', 1538, 'Bram Coomans', 473, 'Nicoletta Susanna Canegrati', 224.00, 1455200552, 1455266349, 1455266349, '70049916', '1016100462', 0, 'sol'),
(10, 311, 'SOL H', 35, 'SOL Hellas', 625, 'Umberto Mazzola', 473, 'Nicoletta Susanna Canegrati', 929.70, 1455200552, 1455266426, 1455266426, '70049911', '1016100457', 0, 'sol'),
(11, 215, 'SOL F/S', 12, 'SOL France', 912, 'Stephan Minchin', 473, 'Nicoletta Susanna Canegrati', 224.00, 1455200552, 1455266437, 1455266437, '70049908', '1016100458', 0, 'sol'),
(12, 306, 'SFF', 1, 'SOL SpA', 1372, 'Mauro Zappulli', 473, 'Nicoletta Susanna Canegrati', 675.00, 1455200552, 1455266415, 1455266415, '70049907', '1016100456', 0, 'sol'),
(13, 89, 'ICOA', 7, 'ICOA', 216, 'Filippo Palmieri', 473, 'Nicoletta Susanna Canegrati', 1396.00, 1455200552, 1455266388, 1455266388, '70049906', '1016700017', 0, 'sol'),
(14, 95, 'BTG', 4, 'BTG Belgische Technische Gassen', 1171, 'Marcel Vermeulen', 473, 'Nicoletta Susanna Canegrati', 200.00, 1455200552, 1455266480, 1455266480, '70049902', '1016100459', 0, 'sol'),
(15, 168, 'TGS', 19, 'TGS', 676, 'Marcel Vermeulen', 473, 'Nicoletta Susanna Canegrati', 750.00, 1455200552, 1452261200, 1455200552, '70049341', '', 0, 'sol'),
(16, 161, 'SOL SRB', 9, 'SOL Serbia', 1091, 'Aleksandar Cadikovsky', 473, 'Nicoletta Susanna Canegrati', 274.50, 1455200552, 1455523931, 1455523931, '70049241', '', 0, 'sol'),
(17, 60, 'SVR', 54, 'SOL Gas Primari', 202, 'Fabrizio Pagani', 473, 'Nicoletta Susanna Canegrati', 7000.55, 1455200552, 1452261200, 1455200552, '70049232', '1015700368', 0, 'sol'),
(18, 353, 'HCT', 2, 'VIVISOL srl', 544, 'Roberto Forlani', 743, 'Nicoletta Susanna Canegrati', 0.00, 1455486457, 1455486457, 1455486457, '70032136', '', 0, 'VIVISOL'),
(19, 169, 'TMG-N', 21, 'SOL Deutschland', 652, 'Dirk Barthel', 473, 'Nicoletta Susanna Canegrati', 0.00, 1455486657, 1455486657, 1455486657, '70036467', '', 0, 'sol'),
(20, 93, 'VIV NA', 29, 'VIVISOL Napoli', 341, 'Lucio Di Franco', 473, 'Nicoletta Susanna Canegrati', 0.00, 1455486746, 1455486746, 1455486746, '70044105', '', 0, 'sol'),
(21, 114, 'VIV SIL', 30, 'VIVISOL Silarus', 106, 'Cesare Pandolfi', 473, 'Nicoletta Susanna Canegrati', 0.00, 1455486825, 1455486825, 1455486825, '70044106', '', 0, 'sol'),
(22, 175, 'VIV A', 24, 'VIVISOL Austria', 2184, 'Dieter Lang', 473, 'Nicoletta Susanna Canegrati', 0.00, 1455486920, 1456820951, 1456820951, '70049249', '5016100006', 0, 'vivisol'),
(23, 410, 'VIV I/S', 42, 'VIVISOL Ibérica', 1510, 'Enrico Attilio Spiaggi', 473, 'Nicoletta Susanna Canegrati', 0.00, 1455487045, 1456820962, 1456820962, '70049251', '5016100007', 0, 'vivisol'),
(24, 179, 'VIV D', 27, 'VIVISOL Deutschland', 730, 'Armin Käsbohrer', 473, 'Nicoletta Susanna Canegrati', 0.00, 1455487222, 1456820824, 1456820824, '70049252', '5016100005', 0, 'vivisol'),
(25, 275, 'VIV H', 50, 'VIVISOL Hellas', 1580, 'Telemaco Tilemachidis', 473, 'Nicoletta Susanna Canegrati', 0.00, 1455487261, 1456820973, 1456820973, '70049253', '5016100008', 0, 'vivisol'),
(26, 313, 'VIV I', 42, 'VIVISOL Ibérica', 1510, 'Enrico Attilio Spiaggi', 473, 'Nicoletta Susanna Canegrati', 0.00, 1455487319, 1455487319, 1455487319, '70049256', '', 0, 'vivisol'),
(27, 313, 'VIV I', 42, 'VIVISOL Ibérica', 1510, 'Enrico Attilio Spiaggi', 473, 'Nicoletta Susanna Canegrati', 0.00, 1455487360, 1456820924, 1456820924, '70049260', '5016100004', 0, 'vivisol'),
(28, 410, 'VIV I/S', 42, 'VIVISOL Ibérica', 1510, 'Enrico Attilio Spiaggi', 473, 'Nicoletta Susanna Canegrati', 0.00, 1455487418, 1456820985, 1456820985, '70049261', '5016100009', 0, 'vivisol'),
(29, 174, 'VIV B', 25, 'VIVISOL Belgium', 940, 'Yves Raveydts', 473, 'Nicoletta Susanna Canegrati', 0.00, 1455487470, 1456821008, 1456821008, '70049263', '5016100010', 0, 'vivisol'),
(30, 89, 'ICOA', 7, 'ICOA', 216, 'Filippo Palmieri', 473, 'Nicoletta Susanna Canegrati', 0.00, 1455487508, 1456821021, 1456821021, '70049264', '5016700003', 0, 'sol'),
(31, 102, 'VIV CAL', 26, 'VIVISOL Calabria', 216, 'Filippo Palmieri', 473, 'Nicoletta Susanna Canegrati', 0.00, 1455487548, 1456821046, 1456821046, '70049266', '5016700005', 0, 'vivisol'),
(32, 93, 'VIV NA', 29, 'VIVISOL Napoli', 341, 'Lucio Di Franco', 473, 'Nicoletta Susanna Canegrati', 0.00, 1455487596, 1456821032, 1456821032, '70049268', '5016700004', 0, 'vivisol'),
(33, 93, 'VIV NA', 29, 'VIVISOL Napoli', 341, 'Lucio Di Franco', 473, 'Nicoletta Susanna Canegrati', 0.00, 1455487636, 1456821080, 1456821080, '70049270', '5016700007', 0, 'vivisol'),
(34, 114, 'VIV SIL', 30, 'VIVISOL Silarus', 106, 'Cesare Pandolfi', 473, 'Nicoletta Susanna Canegrati', 0.00, 1455487681, 1456821060, 1456821060, '70049271', '5016700006', 0, 'vivisol'),
(35, 89, 'ICOA', 7, 'ICOA', 216, 'Filippo Palmieri', 473, 'Nicoletta Susanna Canegrati', 0.00, 1455487721, 1455487721, 1455487721, '70049288', '', 0, 'sol'),
(36, 161, 'SOL SRB', 9, 'SOL Serbia', 1091, 'Aleksandar Cadikovski', 473, 'Nicoletta Susanna Canegrati', 0.00, 1455487755, 1455487755, 1455487755, '70049289', '', 0, 'sol'),
(37, 58, 'SRA', 54, 'SOL Gas Primari', 102, 'Carlo Palagi', 473, 'Nicoletta Susanna Canegrati', 0.00, 1455487796, 1455487796, 1455487796, '70049309', '', 0, 'sol'),
(38, 59, 'SSA', 54, 'SOL Gas Primari', 245, 'Gerardo Bisaccia', 473, 'Nicoletta Susanna Canegrati', 0.00, 1455487842, 1455487842, 1455487842, '70049320', '', 0, 'sol'),
(39, 95, 'BTG', 4, 'BTG Belgische Technische Gassen', 60, 'Andrea Sinigaglia', 473, 'Nicoletta Susanna Canegrati', 596.00, 1456755845, 1456820744, 1456820744, '70050625', '1016109869', 0, 'sol'),
(40, 89, 'ICOA', 7, 'ICOA', 216, 'Filippo Palmieri', 473, 'Nicoletta Susanna Canegrati', 1682.40, 1456757569, 1456820730, 1456820730, '70050629', '1016700027', 0, 'sol'),
(41, 172, 'UTP', 23, 'UTP', 868, 'Vanja Ivancevic', 473, 'Nicoletta Susanna Canegrati', 1041.06, 1456758350, 1455702783, 1456758350, '70050632', '', 0, 'sol'),
(42, 206, 'UTP/Z', 23, 'UTP', 868, 'Vanja Ivančević', 473, 'Nicoletta Susanna Canegrati', 12.80, 1456758360, 1456820713, 1456820713, '70050632', '1016109868', 0, 'sol'),
(43, 164, 'SFY', 1, 'SOL SpA', 1372, 'Mauro Zappulli', 473, 'Nicoletta Susanna Canegrati', 2092.00, 1456759168, 1456820695, 1456820695, '70050636', '1016109867', 0, 'sol'),
(44, 167, 'SOL BG', 17, 'SOL Bulgaria', 2885, 'Marin Dimitrov', 473, 'Nicoletta Susanna Canegrati', 500.00, 1456761707, 1456820680, 1456820680, '70050642', '1016109866', 0, 'sol'),
(45, 156, 'SOL NL', 11, 'SOL Nederland', 1538, 'Bram Coomans', 473, 'Nicoletta Susanna Canegrati', 107.40, 1456761897, 1456820664, 1456820664, '70050643', '1016109865', 0, 'sol'),
(46, 170, 'SOL D/S', 21, 'SOL Deutschland', 1146, 'Donat Rauker', 473, 'Nicoletta Susanna Canegrati', 50.00, 1456762078, 1456820645, 1456820645, '70050645', '1016109864', 0, 'sol'),
(47, 169, 'SOL D/N', 21, 'SOL Deutschland', 1146, 'Donat Rauker', 473, 'Nicoletta Susanna Canegrati', 24.00, 1456762213, 1456820622, 1456820622, '70050646', '1016109863', 0, 'sol'),
(48, 163, 'SOL F/C', 12, 'SOL France', 2414, 'Hocine Abdelouhab', 473, 'Nicoletta Susanna Canegrati', 2732.00, 1456762376, 1456820758, 1456820758, '70050647', '1016109862', 0, 'sol'),
(49, 381, 'Dolby/B', 41, 'Dolby Medical', 2601, 'David Hoggan', 473, 'Nicoletta Susanna Canegrati', 156.00, 1456823083, 1456839391, 1456839391, '70050658', '1016109874', 0, 'sol'),
(50, 6, 'CSTV GE', 2, 'VIVISOL srl', 45, 'Andrea Giribaldi', 473, 'Nicoletta Susanna Canegrati', 36.20, 1456840849, 1455613759, 1456840849, '70050665', '', 0, 'sol'),
(51, 7, 'CSTV GO', 2, 'VIVISOL srl', 575, 'Sergio Candotti', 473, 'Nicoletta Susanna Canegrati', 100.00, 1456840868, 1454946649, 1456840868, '70050665', '', 0, 'sol'),
(52, 75, 'CSTV JE', 2, 'VIVISOL srl', 417, 'Massimo Coppari', 473, 'Nicoletta Susanna Canegrati', 200.30, 1456840899, 1456751827, 1456840899, '70050665', '', 0, 'sol'),
(53, 67, 'CSTV TO', 2, 'VIVISOL srl', 2798, 'Stefano Truccero', 473, 'Nicoletta Susanna Canegrati', 36.20, 1456840921, 1455551226, 1456840921, '70050665', '', 0, 'sol'),
(54, 357, 'DVCN/ROA', 2, 'VIVISOL srl', 2762, 'Sara Bresciani', 473, 'Nicoletta Susanna Canegrati', 1.80, 1456841189, 1455704358, 1456841189, '70050665', '', 0, 'sol'),
(55, 353, 'HCT', 2, 'VIVISOL srl', 544, 'Roberto Forlani', 473, 'Nicoletta Susanna Canegrati', 16.00, 1456841284, 1455533605, 1456841284, '70050665', '', 0, 'sol'),
(56, 57, 'SPB', 1, 'SOL SpA', 81, 'Antonio Dorino', 473, 'Nicoletta Susanna Canegrati', 155.00, 1456847588, 1455288100, 1456847588, '70050667', '', 0, 'sol'),
(57, 58, 'SRA', 54, 'SOL Gas Primari', 102, 'Carlo Palagi', 473, 'Nicoletta Susanna Canegrati', 730.00, 1456848141, 1456913374, 1456913374, '70050669', '1016700029', 0, 'sol'),
(58, 93, 'VIV NA', 29, 'VIVISOL Napoli', 341, 'Lucio Di Franco', 473, 'Nicoletta Susanna Canegrati', 424.00, 1456848781, 1456913637, 1456913637, '70050673', '1016700030', 0, 'sol'),
(59, 176, 'VIV NL', 31, 'VIVISOL Nederland	', 784, 'Patricia Kluitmans', 473, 'Nicoletta Susanna Canegrati', 406.10, 1456849445, 1457103989, 1457103989, '70050678', '5016104383', 0, 'vivisol'),
(60, 102, 'VIV CAL', 26, 'VIVISOL Calabria', 216, 'Filippo Palmieri', 473, 'Nicoletta Susanna Canegrati', 215.28, 1456849547, 1457103977, 1457103977, '70050679', '5016700016', 0, 'vivisol'),
(61, 179, 'VIV D', 27, 'VIVISOL Deutschland', 730, 'Armin Käsbohrer', 473, 'Nicoletta Susanna Canegrati', 12552.00, 1456908342, 1457103922, 1457103922, '70050690', '5016104384', 0, 'vivisol'),
(62, 381, 'Dolby/B', 41, 'Dolby Medical', 2601, 'David Hoggan', 473, 'Nicoletta Susanna Canegrati', 90.00, 1456911942, 1457103911, 1457103911, '70050699', '5016104381', 0, 'vivisol'),
(63, 16, 'CGO BA', 1, 'SOL SpA', 640, 'Vito Romito', 473, 'Nicoletta Susanna Canegrati', 180.00, 1456931030, 1456128902, 1456931030, '70080717', '', 0, 'vivisol'),
(64, 41, 'CGO BO', 1, 'SOL SpA', 369, 'Marco Arzenton', 473, 'Nicoletta Susanna Canegrati', 360.00, 1456931039, 1456475593, 1456931039, '70080717', '', 0, 'vivisol'),
(65, 87, 'CGO CA', 1, 'SOL SpA', 487, 'Paolo Bartalini', 473, 'Nicoletta Susanna Canegrati', 9.00, 1456931053, 1455196211, 1456931053, '70080717', '', 0, 'vivisol'),
(66, 45, 'CGO CT', 1, 'SOL SpA', 294, 'Giuseppe Minutoli', 473, 'Nicoletta Susanna Canegrati', 27.00, 1456931059, 1455718151, 1456931059, '70080717', '', 0, 'vivisol'),
(67, 72, 'CGO RM', 1, 'SOL SpA', 294, 'Giuseppe Minutoli', 473, 'Nicoletta Susanna Canegrati', 720.00, 1456931066, 1455702072, 1456931066, '70080717', '', 0, 'vivisol'),
(68, 52, 'CGO TO', 1, 'SOL SpA', 7, 'Alberto Bergamaschini', 473, 'Nicoletta Susanna Canegrati', 126.00, 1456931072, 1457103966, 1457103966, '70080717', '5016700017', 0, 'vivisol'),
(69, 60, 'SVR', 54, 'SOL Gas Primari', 202, 'Fabrizio Pagani', 473, 'Nicoletta Susanna Canegrati', 208.86, 1456996942, 1457002482, 1457002482, '70050668', '1016700038', 0, 'sol'),
(70, 435, 'SVR/CA', 1, 'SOL SpA', 202, 'Fabrizio Pagani', 473, 'Nicoletta Susanna Canegrati', 225.00, 1456999946, 1457002471, 1457002471, '70050667', '1016700039', 0, 'sol'),
(71, 433, 'SSA/CA', 1, 'SOL SpA', 245, 'Gerardo Bisaccia', 473, 'Nicoletta Susanna Canegrati', 1140.00, 1457011775, 1457013362, 1457013362, '70050746', '1016700041', 0, 'sol'),
(72, 59, 'SSA', 54, 'SOL Gas Primari', 245, 'Gerardo Bisaccia', 473, 'Nicoletta Susanna Canegrati', 116.90, 1457011907, 1457013374, 1457013374, '70050747', '1016700040', 0, 'sol');

-- --------------------------------------------------------

--
-- Table structure for table `qui_RdF_old`
--

CREATE TABLE IF NOT EXISTS `qui_RdF_old` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_unita` int(11) NOT NULL,
  `nome_unita` tinytext NOT NULL,
  `id_resp` int(11) NOT NULL,
  `nome_resp` text NOT NULL,
  `id_buyer` int(11) NOT NULL,
  `nome_buyer` text NOT NULL,
  `totale_RdF` float(14,2) NOT NULL,
  `data_chiusura` int(11) NOT NULL,
  `data_ultima_modifica` int(11) NOT NULL,
  `n_ord_sap` varchar(20) NOT NULL,
  `n_fatt_sap` varchar(20) NOT NULL,
  `flag_fatturata` tinyint(1) NOT NULL,
  `logo` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `qui_richieste_ins_prodotti`
--

CREATE TABLE IF NOT EXISTS `qui_richieste_ins_prodotti` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `obsoleto` tinyint(1) NOT NULL,
  `negozio` tinytext NOT NULL,
  `paese` tinytext NOT NULL,
  `categoria1_it` tinytext NOT NULL,
  `categoria2_it` tinytext NOT NULL,
  `categoria3_it` tinytext NOT NULL,
  `categoria4_it` tinytext NOT NULL,
  `extra` tinytext NOT NULL,
  `descrizione1_it` text NOT NULL,
  `descrizione2_it` text NOT NULL,
  `descrizione3_it` text NOT NULL,
  `descrizione4_it` text NOT NULL,
  `id_valvola` tinytext NOT NULL,
  `id_cappellotto` tinytext NOT NULL,
  `id_pescante` tinytext NOT NULL,
  `codice_art` tinytext NOT NULL,
  `cf` tinytext NOT NULL,
  `codice_numerico` tinytext NOT NULL,
  `gruppo_merci` tinytext NOT NULL,
  `coge` tinytext NOT NULL,
  `wbs` tinytext NOT NULL,
  `prezzo` float(14,2) NOT NULL,
  `confezione` tinytext NOT NULL,
  `foto` text NOT NULL,
  `foto_gruppo` text NOT NULL,
  `foto_famiglia` text NOT NULL,
  `icona` text NOT NULL,
  `rif_famiglia` text NOT NULL,
  `precedenza` int(11) NOT NULL,
  `categoria1_en` tinytext NOT NULL,
  `categoria2_en` tinytext NOT NULL,
  `categoria3_en` tinytext NOT NULL,
  `categoria4_en` tinytext NOT NULL,
  `descrizione1_en` text NOT NULL,
  `descrizione2_en` text NOT NULL,
  `descrizione3_en` text NOT NULL,
  `descrizione4_en` text NOT NULL,
  `filepath` text NOT NULL,
  `codice_originale_duplicato` tinytext NOT NULL,
  `ordine_stampa` tinyint(1) NOT NULL,
  `switch_lista_radio` tinyint(1) NOT NULL,
  `ultima_modifica` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `qui_spedizioni`
--

CREATE TABLE IF NOT EXISTS `qui_spedizioni` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `descrizione` varchar(50) NOT NULL,
  `prezzo` float(8,2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `qui_spedizioni`
--

INSERT INTO `qui_spedizioni` (`id`, `descrizione`, `prezzo`) VALUES
(1, 'Consegna standard', 0.00),
(2, 'Richiesta urgente', 50.00);

-- --------------------------------------------------------

--
-- Table structure for table `qui_temp_righe_pl`
--

CREATE TABLE IF NOT EXISTS `qui_temp_righe_pl` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_riga` int(11) NOT NULL,
  `id_rda` int(11) NOT NULL,
  `id_utente` int(11) NOT NULL,
  `codice_prenotazione` varchar(20) NOT NULL,
  `id_pl` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `qui_utenti_no_mail`
--

CREATE TABLE IF NOT EXISTS `qui_utenti_no_mail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_utente` int(11) NOT NULL,
  `id_resp` int(11) NOT NULL,
  `tx_utente` varchar(30) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `qui_utenti_no_mail`
--

INSERT INTO `qui_utenti_no_mail` (`id`, `id_utente`, `id_resp`, `tx_utente`) VALUES
(1, 201, 169, 'Muzzi'),
(2, 9, 169, 'Cimignaghi'),
(3, 1646, 169, 'Giagnorio'),
(4, 32, 161, 'Balconi');

-- --------------------------------------------------------

--
-- Table structure for table `qui_vettori`
--

CREATE TABLE IF NOT EXISTS `qui_vettori` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `abbreviazione` text NOT NULL,
  `indirizzo_vettore` text NOT NULL,
  `iscrizione` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `qui_vettori`
--

INSERT INTO `qui_vettori` (`id`, `abbreviazione`, `indirizzo_vettore`, `iscrizione`) VALUES
(1, 'AWS L4 Express', 'AWS L4 Express srl<br>Via Iseo 8/C<br>20098 San Giuliano Milanese (MI)', '123456'),
(4, 'Autotrasporti Sorosina', 'Autotrasporti Sorosina srl<br>Via Fiume 25<br>24030 Pianico (BG)', ''),
(5, 'TNT', 'TNT<br>Via Giuliani<br>Peschiera Borromeo (Mi)', ''),
(6, 'BRT', 'BRT<br>Via Monfalcone, 15<br>20052 Cinisello Balsamo (Mi)', ''),
(7, 'Poste espresso', 'Poste italiane<br>Via della Posta<br>Roma', ''),
(8, 'Bloise Francesco', 'Bloise Francesco<br>Via Petrarca 5<br>20852 Villasanta (MB)', ''),
(9, 'Arco Spedizioni', 'Arco Spedizioni SpA<br>via Buonarroti, 203<br>20900 Monza (MB)', ''),
(10, 'Intex', 'INTEX SA<br>Corso S. Gottardo 20<br>CH - 6830 Chiasso', '');

-- --------------------------------------------------------

--
-- Table structure for table `servizio_abbigliamento`
--

CREATE TABLE IF NOT EXISTS `servizio_abbigliamento` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cat4` varchar(10) NOT NULL,
  `descr` varchar(100) NOT NULL,
  `giac_qc` int(11) NOT NULL,
  `giac_mc` int(11) NOT NULL,
  `delta` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2501 ;

--
-- Dumping data for table `servizio_abbigliamento`
--

INSERT INTO `servizio_abbigliamento` (`id`, `cat4`, `descr`, `giac_qc`, `giac_mc`, `delta`) VALUES
(1, 'categoria3', 'categoria4_it', 0, 0, 0),
(1670, 'T-shirt', 'S', 68, 67, -1),
(1671, 'Polo', 'S', 61, 40, -21),
(1790, 'T-shirt', 'M', 304, 306, 2),
(1791, 'T-shirt', 'L', 663, 657, -6),
(1792, 'T-shirt', 'XL', 468, 454, -14),
(1793, 'T-shirt', 'XXL', 225, 212, -13),
(1794, 'T-shirt', 'XXXL', 98, 97, -1),
(1795, 'Polo', 'M', 285, 277, -8),
(1796, 'Polo', 'L', 492, 472, -20),
(1797, 'Polo', 'XL', 407, 395, -12),
(1798, 'Polo', 'XXL', 216, 207, -9),
(1799, 'Polo', 'XXXL', 189, 188, -1),
(1826, 'Felpa', 'S', 38, 31, -7),
(1847, 'Camicia', 'S', 125, 26, -99),
(1852, 'Camicia', 'M', 254, 270, 16),
(1853, 'Camicia', 'L', 590, 550, -40),
(1854, 'Camicia', 'XL', 394, 484, 90),
(1855, 'Camicia', 'XXL', 290, 244, -46),
(1856, 'Camicia', 'XXXL', 176, 176, 0),
(1941, 'Felpa', 'M', 38, 172, 134),
(1942, 'Felpa', 'L', 38, 322, 284),
(1943, 'Felpa', 'XL', 38, 361, 323),
(1944, 'Felpa', 'XXL', 38, 166, 128),
(1945, 'Felpa', 'XXXL', 38, 85, 47),
(2349, 'Pantalone', 'XS', 15, 15, 0),
(2350, 'Pantalone', 'S', 6, 4, -2),
(2351, 'Pantalone', 'M', 205, 200, -5),
(2352, 'Pantalone', 'L', 310, 296, -14),
(2353, 'Pantalone', 'XL', 135, 153, 18),
(2354, 'Pantalone', 'XXL', 47, 43, -4),
(2355, 'Pantalone', 'XXXL', 0, 0, 0),
(2356, 'Scarpe', '35', 0, 0, 0),
(2357, 'Scarpe', '36', 4, 4, 0),
(2358, 'Scarpe', '37', 2, 2, 0),
(2359, 'Scarpe', '38', 3, 4, 1),
(2360, 'Scarpe', '39', 5, 9, 4),
(2361, 'Scarpe', '40', 7, 4, -3),
(2362, 'Scarpe', '41', 65, 67, 2),
(2363, 'Scarpe', '42', 107, 121, 14),
(2364, 'Scarpe', '43', 72, 87, 15),
(2365, 'Scarpe', '44', 72, 70, -2),
(2366, 'Scarpe', '45', 56, 59, 3),
(2367, 'Scarpe', '46', -2, 1, 3),
(2368, 'Scarpe', '47', 0, 5, 5),
(2369, 'Pantalone', 'XS', 15, 18, 3),
(2377, 'Giacca_2_i', 'S', 0, 0, 0),
(2378, 'Giacca_2_i', 'M', 16, 11, -5),
(2379, 'Giacca_2_i', 'L', 82, 88, 6),
(2380, 'Giacca_2_i', 'XL', 59, 83, 24),
(2381, 'Giacca_2_i', 'XXL', 16, 15, -1),
(2382, 'Giacca_2_i', 'XXXL', 11, 11, 0),
(2383, 'Pantalone', 'S', 6, 39, 33),
(2384, 'Pantalone', 'M', 205, 275, 70),
(2385, 'Pantalone', 'L', 310, 474, 164),
(2386, 'Pantalone', 'XL', 135, 200, 65),
(2387, 'Pantalone', 'XXL', 47, 120, 73),
(2388, 'Pantalone', 'XXXL', 0, 50, 50),
(2495, 'Giacca_2_i', 'S', 8, 6, -2),
(2496, 'Giacca_2_i', 'M', 110, 97, -13),
(2497, 'Giacca_2_i', 'L', 198, 185, -13),
(2498, 'Giacca_2_i', 'XL', 176, 131, -45),
(2499, 'Giacca_2_i', 'XXL', 65, 34, -31),
(2500, 'Giacca_2_i', 'XXXL', 42, 34, -8);

-- --------------------------------------------------------

--
-- Table structure for table `uc_order_statuses`
--

CREATE TABLE IF NOT EXISTS `uc_order_statuses` (
  `order_status_id` varchar(32) NOT NULL DEFAULT '',
  `title_it` tinytext NOT NULL,
  `title` varchar(48) NOT NULL,
  `state` varchar(32) NOT NULL DEFAULT '',
  `weight` smallint(6) NOT NULL DEFAULT '0',
  `locked` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `status_php` tinyint(4) NOT NULL,
  `attivo` tinyint(1) NOT NULL,
  `attivo_admin` tinyint(1) NOT NULL,
  PRIMARY KEY (`order_status_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `uc_order_statuses`
--

INSERT INTO `uc_order_statuses` (`order_status_id`, `title_it`, `title`, `state`, `weight`, `locked`, `status_php`, `attivo`, `attivo_admin`) VALUES
('canceled', '', 'Canceled', 'canceled', -19, 1, 0, 0, 0),
('in_checkout', '', 'User review', 'in_checkout', -10, 1, 1, 0, 0),
('pending', 'In attesa', 'Evaluation', 'post_checkout', 1, 1, 1, 0, 1),
('processing', '', 'Processing', 'post_checkout', 5, 1, 4, 0, 0),
('completed', 'Completata', 'Completed', 'completed', 20, 1, 4, 1, 1),
('buyer', 'Approvata', 'Send to buyer', 'post_checkout', 0, 0, 2, 0, 1);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
